Autopipe_vis=function(sample_data,
                      Choice=c("group"),
                      threshold=1,
                      pal=viridis(50)){
  
  message("Start Autopipe")
  
  
  
  
  
  
  
}