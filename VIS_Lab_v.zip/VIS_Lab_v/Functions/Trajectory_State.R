Trajectory_State=function(sample, Geneset,
                          xscale=10,
                          yscale=1, 
                          cex=1.5,
                          col_samples="NA",
                          pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10), 
                          genes="NA",
                          signature="NA",
                          Plot=T,
                          cex_GS=0.2,
                          coordinates=NA)
{
  
  
  
  ########################################
  #Function required
  ########################################
  plot_score_map=function(x=1:10,coordinates=c(4.5, 5, 0.8, 1),z_scored=T, cex=0.8, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min, max, length.out = 5), digits = 1)
    
    
    #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
    pal= colorRampPalette(pal)(50)
    
    length_x=as.numeric((coordinates[2]-coordinates[1])/4)
    length_y=as.numeric((coordinates[4]-coordinates[3])/50)
    for(i in 1:length(pal)){
      
      polygon(x=c(coordinates[1], coordinates[1]+length_x),y=c(coordinates[3]+i*length_y, coordinates[3]+i*length_y),lwd=4,border = pal[i])
      
    }
    x_task= coordinates[1]+length_x*1.3
    arrows(x_task,coordinates[3], x_task, coordinates[4]+length_y*5, length = length_x/8)
    xx=seq(coordinates[3],coordinates[4],length.out = 5)
    for ( i in 1: length(xx)){
      polygon(x=c(x_task,x_task+length_x*0.2), y=c(xx[i],xx[i] ),lwd=0.5, border = "black")
      text(x=c(x_task+length_x*2), y=xx[i], labels = val[i], cex=0.8)
    }
    
    text(x=x_task, y=coordinates[4]+length_y*10, labels = "Z-Score", cex=cex)
    
  }
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  require(RColorBrewer)
  require(scales)
  require(dplyr)
  require(viridis)
  ########################################
  #Define Input
  ########################################
  expr=sample@data@norm_Exp
  if(is.null(expr)) stop("sample@data@norm_Exp is not avaiable in input")
  
  #Load genesets and transforme input to data.frame
  GS=sample@Gene_Sets_used
  GS1=GS %>% filter(GS$ont %in% Geneset) 
  
  
  geneSets=lapply(1:4, function(i){GS1[GS1$ont==Geneset[i], "gene" ]})
  names(geneSets)=Geneset
  
  
  print(signature)
  if(!is.na(signature)){
    geneSets_signature=lapply(1, function(i){GS[GS$ont==signature, "gene" ]})
    names(geneSets_signature)=signature
    geneSets=c(geneSets,geneSets_signature)
  }
  
  
  
  
  #Use GSVA to get enrichment Scores for each sample 
  gs_out=GSVA::gsva(expr, geneSets, mx.diff=1)
  print(gs_out)
  
  #Normalize Score 
  normalize_DHH=function(x){(x-min(x))/(max(x)-min(x))}
  #for(i in 1:ncol(gs_out)){gs_out[,i]=normalize_DHH(gs_out[,i])}
  nrx=t(gs_out)
  
  print(signature)
  #Set color
  if(signature!="NA"){color_set=map2color( nrx[,signature], pal )}
  if(genes!="NA"){color_set=map2color( expr[rownames(expr) %in% genes, ], pal )}
  if(col_samples!="NA"){color_set=as.character(map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[1]])}
  if (signature=="NA" & genes=="NA" & col_samples=="NA"){color_set=c(rep("black", nrow(nrx)))}
  print(color_set)
  
  #xscale=1.2
  
  print(nrx)
  
  if(Plot==T){
    par(las=1, mar=c(5,5,5,5))
    plot(NA, bty="n", type="n", axes=F, 
         xlab="", 
         ylab="",
         xlim=c(-(xscale+(xscale/2)),xscale+(xscale/2)), 
         ylim=c(-(xscale+(xscale/2)),xscale+(xscale/2)), 
         cex=2, lwd=0.5)
    polygon(x=c(-xscale,xscale,xscale,-xscale), y=c(xscale,xscale,-xscale,-xscale), lty=2)
    arrows(-xscale, xscale+(xscale/10) ,xscale, xscale+(xscale/10), length = 0.1, code=3 )
    arrows(xscale +(xscale/10), -xscale ,xscale+(xscale/10), xscale, length = 0.1, code=3 )
    text(x=0, y=xscale+((xscale/10)*2), labels = "Trajectory State 1 vs State 2", cex=cex_GS)
    text(y=0, x=xscale+((xscale/10)*2), labels = "Trajectory State 3 vs State 4", srt=270, cex=cex_GS)
    
    if(col_samples=="NA"){
      plot_score_map(x=1:10,coordinates=c((-(xscale+(xscale/3))), (-(xscale+(xscale/10))) , 0, xscale/1.3),overlay=T, pal=viridis(50) )
      
    }
    
    mat_coordinates=matrix(NA, nrow(nrx), 2)
    colnames(mat_coordinates)=c("x", "y")
    
    for(i in 1:nrow(nrx)){
      #print(nrx$col[i])
      nr=as.numeric(nrx[i,1:4 ])
      #define fetal vs. adult y axis
      y_a=nr[4]-nr[3]
      if(y_a>0){y=as.numeric(log2(abs(y_a)))}
      if(y_a<0){y=as.numeric(-log2(abs(y_a)))}
      
      print(y_a)
      
      #define A1 vs. A2 y axis
      y_a_X=nr[2]-nr[1]
      if(y_a_X>0){x=as.numeric(log2(abs(y_a_X)))}
      if(y_a_X<0){x=as.numeric(-log2(abs(y_a_X)))}
      
      
      print(y_a_X)
      
      points(y=y,x=x, col=color_set[i], pch=16,cex=cex)
      mat_coordinates[i, ]=c(x,y)
      
    }
    #text(x=(-xscale)+(xscale/2), y=xscale, labels = colnames(nrx)[1], cex=cex_GS )
    #text(x=(xscale)-(xscale/2), y=xscale, labels = colnames(nrx)[2], cex=cex_GS)
    #text(x=(-xscale)+(xscale/2), y=-xscale, labels = colnames(nrx)[3], cex=cex_GS)
    #text(x=(xscale)-(xscale/2), y=-xscale, labels = colnames(nrx)[4], cex=cex_GS)
    
    
    points(x=c(-xscale,xscale), y=c(0,0), type="l", lty=2)
    points(y=c(-xscale,xscale), x=c(0,0), type="l", lty=2)
    
    if(col_samples!="NA"){
      out_samp=map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[2]]
       for(i in 1: nrow(out_samp)){
         dist=(xscale*2)/nrow(out_samp)-1
         points(x=-(xscale+dist)+dist*i, y=-(xscale+xscale/4), pch=16, cex=1, col=out_samp$col[i])
         text(x=(-(xscale+dist)+dist*i)+dist/2, y=-(xscale+xscale/4), labels = out_samp$Terms[i], cex=cex_GS)
       }


}
    
    
  }
  
  if(!is.na(coordinates)){return(mat_coordinates)}else{return(nrx)}
  
}







