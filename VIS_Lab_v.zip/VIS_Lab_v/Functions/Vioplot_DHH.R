Vioplot_DHH=function(
  mat,
  color= RColorBrewer::brewer.pal(9, "Set1"),
  ylab="",
  xlab="",
  h=0.1){
  library(RColorBrewer)
  require(vioplot)
  par(mar=c(15,7,5,5), las=2,  bty="n")
  inp=lapply(1:ncol(mat), function(i) mat[,i])
  names(inp)=colnames(mat)
  
  vioplot(inp,
          las = 2, 
          col = color,
          xlab = xlab,
          ylab=ylab,
          wex=1,
          range=1, 
          h=h,
          na.rm=T
          )
  
}
