

#Variables
#sample class VIZ_MILO output file
#Geneset Input 4 Geneneset from the MsigDB1



Metaplot_4D_DASH=function(sample, Geneset,
                                         xscale=1,
                                         yscale=1, 
                                         cex=1.5, 
                                         col_samples="NA",
                                         pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10), 
                                         genes="NA",
                                         signature="NA",
                                         Plot=T,
                                         cex_GS=0.2)
  {
  
  
  
  ########################################
  #Function required
  ########################################
  plot_score_map=function(x,coordinates=c(1,1),z_scored=T, overlay=F, pal=pal){
    
    if(z_scored==T){max=1;min=-1}else{max=max(x);min=min(x)}
    val=round(seq(min, max, length.out = length(pal)+1), digits = 1)
    
    if(overlay==T){
      #plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
      pal= colorRampPalette(pal)(10)
      polygon(x=c(coordinates[2], coordinates[2]+1, coordinates[2]+1, coordinates[2]),y=c(1,1,length(pal)+1,length(pal)+1), border = "black")
      polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.5),y=c(1,length(pal)+1), border = "black")
      polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.7),y=c(length(pal)+1,length(pal)+1), border = "black")
      text(x=coordinates[2]+2.4, y=length(pal)+1, labels = val[length(pal)+1])
      for(i in 1:length(pal)){
        xx=c(coordinates[2], coordinates[2]+1, coordinates[2]+1, coordinates[2])
        yy=c(i,i,i+1,i+1)
        polygon(xx,yy,col=pal[i], border = NA)
        polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.7),y=c(i,i), border = "black")
        text(x=coordinates[2]+3, y=i, labels = val[i])
        
      }}
    else{
      plot(NA,axes=F,xlab="", ylab="", bty="n", xlim=c(1,10), ylim=c(0,length(pal)+2))
      polygon(x=c(coordinates[2], coordinates[2]+1, coordinates[2]+1, coordinates[2]),y=c(1,1,length(pal)+1,length(pal)+1), border = "black")
      polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.5),y=c(1,length(pal)+1), border = "black")
      polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.7),y=c(length(pal)+1,length(pal)+1), border = "black")
      text(x=coordinates[2]+2.4, y=length(pal)+1, labels = val[length(pal)+1])
      for(i in 1:length(pal)){
        xx=c(coordinates[2], coordinates[2]+1, coordinates[2]+1, coordinates[2])
        yy=c(i,i,i+1,i+1)
        polygon(xx,yy,col=pal[i], border = NA)
        polygon(x=c(coordinates[2]+1.5, coordinates[2]+1.7),y=c(i,i), border = "black")
        text(x=coordinates[2]+2.4, y=i, labels = val[i])
        
      }
      
    }
  }
  map2color<-function(x,pal,limits=NULL){
    if(class(x)=="numeric"){
      if(is.null(limits)) limits=range(x)
      pal[findInterval(x,seq(limits[1],limits[2],length.out=length(pal)+1), all.inside=TRUE)]
    }else{
      print(x[!duplicated(x)])
      da=data.frame(Terms=x[!duplicated(x)], Nr=seq(1,length.out = length(x[!duplicated(x)])))
      da$col=colorRampPalette(pal)(nrow(da))[da[,2]]
      daf=data.frame(x=x, col=1)
      for(i in 1:length(x)){
        daf[i, ]$col=da[da$Terms==daf[i, "x"], ]$col
        
      }
      
      return(list(daf$col, da))
    }
    
  }
  require(RColorBrewer)
  require(scales)
  require(dplyr)
  require(viridis)
  ########################################
  #Define Input
  ########################################
  expr=sample@data@norm_Exp
  if(is.null(expr)) stop("sample@data@norm_Exp is not avaiable in input")
  
  #Load genesets and transforme input to data.frame
  GS=sample@Gene_Sets_used
  GS1=GS %>% filter(GS$ont %in% Geneset) 


  geneSets=lapply(1:4, function(i){GS1[GS1$ont==Geneset[i], "gene" ]})
  names(geneSets)=Geneset
  

  print(signature)
  if(!is.na(signature)){
    geneSets_signature=lapply(1, function(i){GS[GS$ont==signature, "gene" ]})
    names(geneSets_signature)=signature
    geneSets=c(geneSets,geneSets_signature)
    }
  
  
  
  
  #Use GSVA to get enrichment Scores for each sample 
  gs_out=GSVA::gsva(expr, geneSets, mx.diff=1)
  print(gs_out)
  
  #Normalize Score 
  normalize_DHH=function(x){(x-min(x))/(max(x)-min(x))}
  #for(i in 1:ncol(gs_out)){gs_out[,i]=normalize_DHH(gs_out[,i])}
  nrx=t(gs_out)

  print(signature)
  #Set color
  if(signature!="NA"){color_set=map2color( nrx[,signature], pal )}
  if(genes!="NA"){color_set=map2color( expr[rownames(expr) %in% genes, ], pal )}
  if(col_samples!="NA"){color_set=as.character(map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[1]])}
  if (signature=="NA" & genes=="NA" & col_samples=="NA"){color_set=c(rep("black", nrow(nrx)))}
  print(color_set)
  
  #xscale=1.2
  
  if(Plot==T){
    par(las=1, mar=c(5,5,5,5))
    plot(NA, bty="o", type="n", axes=T, 
         xlab=bquote(paste("log2(GSV-Score "[Geneset[1]]*" - GSV-Score "[Geneset[2]]*")") ), 
         ylab=bquote(paste("log2(GSV-Score "[Geneset[3]]*" - GSV-Score "[Geneset[4]]*")") ),
         xlim=c(-xscale,xscale), ylim=c(-xscale,xscale), cex=2, lwd=0.5)
    axis(side=3, labels=FALSE,tck = -0.01)
    axis(side=4, labels=FALSE,tck = -0.01)
    for(i in 1:nrow(nrx)){
      #print(nrx$col[i])
      nr=as.numeric(nrx[i,1:4 ])
      z=max(c(nr[1],nr[2]))-max(c(nr[3],nr[4]))
      
      
      
      if(z<0 & nr[3]>nr[4] ){x=as.numeric(-log2(abs(nr[3]-nr[4]+1)))}
      if(z<0 & nr[3]<nr[4] ){x=as.numeric(log2(abs(nr[4]-nr[3]+1)))}
      
      if(z>0 & nr[1]>nr[2] ){x=as.numeric(-log2(abs(nr[1]-nr[2]+1)))}
      if(z>0 & nr[1]<nr[2] ){x=as.numeric(log2(abs(nr[2]-nr[1]+1)))}
      
      if(z<0){z=as.numeric(-log2(abs(max(c(nr[3],nr[4]))-max(c(nr[1],nr[2]))+1)))}
      if(z>0){z=as.numeric(log2(abs(max(c(nr[1],nr[2]))-max(c(nr[4],nr[3]))+1)))}
      
      points(y=z,x=x, col=color_set[i], pch=16,cex=cex)
      
      
    }
    text(x=(-xscale)+(xscale/2), y=xscale, labels = colnames(nrx)[1], cex=cex_GS )
    text(x=(xscale)-(xscale/2), y=xscale, labels = colnames(nrx)[2], cex=cex_GS)
    text(x=(-xscale)+(xscale/2), y=-xscale, labels = colnames(nrx)[3], cex=cex_GS)
    text(x=(xscale)-(xscale/2), y=-xscale, labels = colnames(nrx)[4], cex=cex_GS)
    
    
    points(x=c(-xscale*2,xscale*2), y=c(0,0), type="l", lty=2)
    points(y=c(-xscale*2,xscale*2), x=c(0,0), type="l", lty=2)
  }
  
  if(col_samples!="NA"){
    out_samp=map2color( sample@fdata[,col_samples], brewer.pal(9,"Set1") )[[2]]
    for(i in 1: nrow(out_samp)){
      dist=(xscale*2)/nrow(out_samp)
      points(y=0-(dist/4)*i, x=-(xscale-xscale/20), pch=16, cex=1, col=out_samp$col[i])
      text(y=0-(dist/4)*i, x=-(xscale-xscale/5), labels = out_samp$Terms[i], cex=cex_GS)
    }
    
    
  }
  
  return(nrx)
  
}






