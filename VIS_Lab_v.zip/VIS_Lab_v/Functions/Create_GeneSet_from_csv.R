#Scores Reactive Astrocytes 
setwd("~/Desktop/Project_Microglia/Revision/RNA")
options(stringsAsFactors = F)
GenesetAstro=as.data.frame(do.call(cbind, readRDS("List_genes.R")))
names(GenesetAstro)=c("A1", "A2", "fetal", "adult")
GenesetMM=read.table("~/Desktop/TCGA Data/scRNAseq_GBM_Pedriatic/IDHwt.GBM.MetaModules.tsv", header=T, stringsAsFactors = F)

D1=data.frame(do.call(rbind, lapply(1:4, function(i){

  dat=data.frame(gene=GenesetAstro[,i], ont=paste0("MILO_Astro_",names(GenesetAstro)[i]))
  dat=dat[,c(2,1)]
  
})))
D2=read.csv("GS_Astro_Microglia.csv", sep=";")
D3=data.frame(do.call(rbind, lapply(1:8, function(i){
  
  dat=data.frame(gene=as.character(na.omit(GenesetMM[,i])), ont=paste0("Neftel_",names(GenesetMM)[i]))
  dat=dat[,c(2,1)]
  
})))
D4=rbind(
  data.frame(gene=c(as.character(na.omit(GenesetMM[,c(1)])),as.character(na.omit(GenesetMM[,c(2)])) ), 
             ont=paste0("Neftel_Mes_Comb")),
  
  data.frame(gene=c(as.character(na.omit(GenesetMM[,c(5)])),as.character(na.omit(GenesetMM[,c(5)])) ), 
             ont=paste0("Neftel_NPC_Comb"))
)
D4=D4[,c(2,1)]

GS_Milo=rbind(D1,D2,D3,D4)
saveRDS(GS_Milo,"MILO_Geneset.RDS")
