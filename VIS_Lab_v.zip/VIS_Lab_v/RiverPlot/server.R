##----------------------------------------------------------------------------##
## Server-tab_RiverPlot
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## uiOutput
##----------------------------------------------------------------------------##

output$Geneset_x=renderUI({
  selectInput(inputId="Geneset_x", 
              label="Select Pathway:",
              choices = c(NA,as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[1]
  )
})
output$Gene_x=renderUI({
  selectInput(inputId="Gene_x", 
              label="Select Gene",
              choices = c(NA,rownames(sample_data()@data@norm_Exp)),
              selected= NA,
              multiple = TRUE
  )
})
output$modus_x=renderUI({
  selectInput(inputId="modus_x", 
              label="Select Experimental Setting:",
              choices = c(as.character(unique(sample_data()@condition_Analysis))),
              selected= c(as.character(unique(sample_data()@condition_Analysis)))[1]
  )
})

output$Sample_Selection=renderUI({
  selectInput(inputId="Sample_Selection", 
              label="Select and order input samples:",
              choices = c(as.character(unique(sample_data()@fdata$group))),
              selected= {
                selector_inp=c(as.character(unique(sample_data()@fdata$group)))[1:3]
                if (length(selector_inp)<3){c(as.character(unique(sample_data()@fdata$group)))[1:2]}else{c(as.character(unique(sample_data()@fdata$group)))[1:3]} },
              multiple = TRUE
  )
})




##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
require(GSVA)
require(pheatmap)
source(paste0(folder,"/Functions/River_Plot_Function.R"),local = T)









##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##

mat_out=reactive({
  order_input=input$Sample_Selection
  print(order_input)
  
  mat_x=River_Plot_Function(sample_data(),
                            modus=input$modus_x, 
                            Geneset=input$Geneset_x, 
                            genes=input$Gene_x, 
                            order=input$Sample_Selection,
                            plot=F)
  print(head(mat_x))
  mat_x=t(mat_x)
  mat_x=na.omit(mat_x)
  return(mat_x)})

output$Riverplot <- renderPlot({
  
  print(input$Geneset_x)
  mat_x=River_Plot_Function(sample=sample_data(),order=input$Sample_Selection, modus=input$modus_x, Geneset=input$Geneset_x, genes=input$Gene_x)
  
 
})

output$Heatmap_River <- renderPlot({
    ## order matrix
    mat_river=t(mat_out())
    mat_river=mat_river[,9:ncol(mat_river)]
    order_n=as.data.frame(do.call(rbind,lapply(1:nrow(mat_river), function(i){
      print(i)
      out=data.frame(Max=max(mat_river[i,], na.rm = T), ID=as.numeric(which(mat_river[i,]==max(mat_river[i,],na.rm = T))))
      print(nrow(out))
      return(out[1, ])
    })))

    rownames(order_n)=rownames(mat_river)

    order_n=order_n[order(order_n$ID), ]

    

    mat_river=mat_river[rownames(order_n), ]

    pheatmap::pheatmap(as.matrix(mat_river),
                     cluster_row = F,
                     cluster_cols = F,
                     scale="row",
                     color = viridis(50), 
                     show_colnames=F)
  
  
})





# Downloads of Plots  
output$downloadplot_Riverplot <- downloadHandler(
  filename = function() { paste("Riverplot", input$Geneset_x,"_",input$modus_x,'.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    River_Plot_Function(sample_data(),order=input$Sample_Selection,modus=input$modus_x, Geneset=input$Geneset_x, genes=input$Gene_x)
    
    dev.off()},
  contentType = "application/pdf"
)

output$downloadHeatmap_River <- downloadHandler(
  filename = function() { paste("Heatmap_Time", input$Geneset_x, '.pdf', sep='') },
  content = function(file) {
    pdf(file, useDingbats = F)
    
    ## order matrix
    mat_river=t(mat_out())
    mat_river=mat_river[,9:ncol(mat_river)]
    order_n=as.data.frame(do.call(rbind,lapply(1:nrow(mat_river), function(i){
      print(i)
      out=data.frame(Max=max(mat_river[i,], na.rm = T), ID=as.numeric(which(mat_river[i,]==max(mat_river[i,],na.rm = T))))
      print(nrow(out))
      return(out[1, ])
    })))

    rownames(order_n)=rownames(mat_river)

    order_n=order_n[order(order_n$ID), ]

    

    mat_river=mat_river[rownames(order_n), ]

    pheatmap::pheatmap(as.matrix(mat_river),
                     cluster_row = F,
                     cluster_cols = F,
                     scale="row",
                     color = viridis(50),
                     show_colnames=F)
    dev.off()},
  contentType = "application/pdf"
)


