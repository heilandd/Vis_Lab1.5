
##----------------------------------------------------------------------------##
## UI-tab_RiverPlot
##----------------------------------------------------------------------------##

tab_RiverPlot <- tabItem(
  tabName = "RiverPlot",

  fluidRow(

    #Selection Box
    box(
      width = 4, status = "warning", solidHeader = TRUE,
      title = "Select conditions for River Plot:",
      
      #### Checkbox for Groups
      uiOutput("modus_x"),
      uiOutput("Geneset_x"),
      uiOutput("Gene_x"),
      "Here please define Samples that need to be analzyed and define the order (At least 3 sample in a row):",
      uiOutput("Sample_Selection")

      
    ),
    
    
    #Plot TabBox
    tabBox(
      title = "", 
      id="Plots_RiverPlot",
      width = 8,
      height = 600,
      
      tabPanel(title="River Plot",
               downloadLink("downloadplot_Riverplot", "PDF"),
               plotOutput("Riverplot")
               ),
      
      tabPanel(title="Heatmap Time: ",
               downloadLink("downloadHeatmap_River", "PDF"),
               plotOutput("Heatmap_River")
               )
      
    )
    


    
    ),
  )


