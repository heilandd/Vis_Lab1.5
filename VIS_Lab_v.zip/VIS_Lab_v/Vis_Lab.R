Vis_Lab <- function(
  folder=getwd()
){
  
  source(paste0(folder,"/Package_check.R"))
  
  
  #Check installed packges
  checkP_DHH(readRDS(paste0(folder,"/packages.RDS")))
  
  
  library(shinydashboard)
  library(shinyWidgets)
  library(shiny)
  library(shinydashboardPlus)
  library(dash)
  library(shinycssloaders)
  library(plotly)
  library(pheatmap)
  library(dashboardthemes)
  
  ################## Sources of shiny parts of the App

  ##--------------------------------------------------------------------------##
  ## Load server and UI functions.
  ##--------------------------------------------------------------------------##
  
  
  setwd(folder)
  
  assign("folder", value =folder , envir = globalenv())
  
  
  readout=readRDS(paste0(folder,"/login_data.RDS"))
  assign("login_data", value =readout , envir = globalenv())
  
  source(paste0(folder,"/App/ALL_UI.R"))
  source(paste0(folder,"/App/ALL_server.R"))
  ##--------------------------------------------------------------------------##
  ## Launch app.
  ##--------------------------------------------------------------------------##
  
  app=shinyApp(ui = ui, server = server)
  runApp(app, launch.browser=T)
  
}

  
Vis_Lab()


#Add User:

#login_data=data.frame(username=c("DHH", "VR", "KJ"), password=c("DHH", "VR", "KJ"))
#saveRDS(login_data, "login_data.RDS")
#shinyApp(ui = ui, server = server)














