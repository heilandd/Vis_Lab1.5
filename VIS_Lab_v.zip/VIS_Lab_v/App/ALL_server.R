##----------------------------------------------------------------------------##
##  Server Functions 
##----------------------------------------------------------------------------##

server <- function(input, output, session) {
  
  #print("start")
  
  ##--------------------------------------------------------------------------##
  ## User Login
  ##--------------------------------------------------------------------------##
  values <- reactiveValues(authenticated = FALSE)
  
  dataModal <- function(failed = FALSE) {
    modalDialog(
      "Please sign in, in case you hve no access, please contact: dieter.henrik.heiland@uniklinik-freiburg.de",
      textInput("username", "Username:"),
      passwordInput("password", "Password:"),
      footer = tagList(
        # modalButton("Cancel"),
        actionButton("ok", "Login")
      )
    )
  }
  
  obs1 <- observe({
    showModal(dataModal())
  })

  
  obs2 <- observe({
    print(input$ok)
    req(input$ok)
    isolate({
      Username <- input$username
      Password <- input$password
    })
	
    Id.username <- which(login_data$username == Username)
    Id.password <- which(login_data$password == Password)
    if (length(Id.username) > 0 & length(Id.password) > 0) {
      #print(c(Id.username,Id.password))
      if (Id.username == Id.password) {
        #print("authenticated is TRUE")
        #Logged <<- TRUE
        values$authenticated <- TRUE
        obs1$suspend()
        removeModal()
        
      } else {
        values$authenticated <- FALSE
      }     
    }
  })
  
  
  
  
  options(shiny.maxRequestSize=1000*1024^2)
  
  ##--------------------------------------------------------------------------##
  ## Colors
  ##--------------------------------------------------------------------------##
  
  
  ##--------------------------------------------------------------------------##
  ## Central parameters.
  ##--------------------------------------------------------------------------##
  scatter_plot_dot_size <- list(
    min = 1,
    max = 20,
    step = 1,
    default = 5
  )
  
  scatter_plot_alpha <- list(
    min = 0.1,
    max = 1.0,
    step = 0.1,
    default = 1.0
  )
  
  preferences <- reactiveValues(use_webgl = TRUE)
  
  ##--------------------------------------------------------------------------##
  ## Sidebar menu.
  ##--------------------------------------------------------------------------##
  output[["sidebar_menu"]] <- renderMenu({
    sidebarMenu(id = "sidebar",
                menuItem(
                  "Load data", tabName = "loadData",
                  icon = icon("spinner"), selected = TRUE
                ),
                menuItem(
                  "DE-Analysis", tabName = "DEAnalysis",
                  icon = icon("brain"), selected = F
                ),
                menuItem(
                  "GSEA", tabName = "GSEA",
                  icon = icon("chart-line"), selected = F
                ),
                menuItem(
                  "State Scatter", tabName = "StatePlots",
                  icon = icon("project-diagram"), selected = F
                ),
                menuItem(
                  "River Plots", tabName = "RiverPlot",
                  icon = icon("arrows-alt-h"), selected = F
                )
                

    )
  })

  
  ##--------------------------------------------------------------------------##
  ## Sample data
  ##--------------------------------------------------------------------------##
  sample_data <- reactive({
    if ( is.null(input[["input_file"]]) || is.na(input[["input_file"]]) ) {
      sample_data <- readRDS(paste0(folder,"/sample_data.RDS"))
      print("We use non selected DF")
      return(sample_data)
    } else {
      req(input[["input_file"]])
      sample_data <- readRDS(input[["input_file"]]$datapath)
      print(sample_data@fdata)
      print(sample_data@data@counts[1:4,1:4])
      return(sample_data)
    }
  })
  
  
  
  ##--------------------------------------------------------------------------##
  ## Tabs.
  ##--------------------------------------------------------------------------##
  source(paste0(folder,"/Test/server.R"), local = T)
  source(paste0(folder,"/DE/server.R"), local = T)
  source(paste0(folder,"/GSEA/server.R"), local = T)
  source(paste0(folder,"/State_Plots/server.R"), local = T)
  source(paste0(folder,"/RiverPlot/server.R"), local = T)
  
}

