##----------------------------------------------------------------------------##
## Custom functions.
##----------------------------------------------------------------------------##
APPBox <- function(title, content) {
  box(
    title = title,
    status = "primary",
    solidHeader = TRUE,
    width = 12,
    collapsible = TRUE,
    content
  )
}
APPInfoButton <- function(id) {
  actionButton(
    inputId = id,
    label = "info",
    icon = NULL,
    class = "btn-xs",
    title = "Show additional information for this panel."
  )
}
boxTitle <- function(title) {
  p(title, style = "padding-right: 5px; display: inline")
}

##----------------------------------------------------------------------------##
##
##----------------------------------------------------------------------------##

source(paste0(folder,"/Test/ui.R"),local = T)
source(paste0(folder,"/DE/ui.R"),local = T)
source(paste0(folder,"/GSEA/ui.R"),local = T)
source(paste0(folder,"/State_Plots/ui.R"),local = T)
source(paste0(folder,"/RiverPlot/ui.R"),local = T)
##----------------------------------------------------------------------------##
##
##----------------------------------------------------------------------------##
ui <- dashboardPage(skin = "blue",
  dashboardHeader(
    title = span("VIS_Lab v1.5 ", style = "color: white; font-size: 28px; font-weight: bold")
  ),
  dashboardSidebar(
    tags$head(tags$style(HTML(".content-wrapper {overflow-x: scroll;}"))),
    tags$head(tags$style(HTML("#dropdown-menu-MyDropDownB1 {
                      background-color: #2A3742 !important;}
               "))),
    tags$style(type="text/css",
               ".shiny-output-error { visibility: hidden; }",
               ".shiny-output-error:before { visibility: hidden; }",
               "body{
    min-height: 611px;
    height: auto;
    max-width: 1200px;
    margin: auto;
        }"),
    
    sidebarMenu(
      sidebarMenuOutput("sidebar_menu")
    )
  ),
  dashboardBody(
    shinyDashboardThemes(theme = "grey_dark"),
    tags$script(HTML('$("body").addClass("fixed");')),
    tabItems(
      tab_load_data,
      tab_DEAnalysis,
      tab_GSEA,
      tab_State_Plots,
      tab_RiverPlot
    )
  )
)

