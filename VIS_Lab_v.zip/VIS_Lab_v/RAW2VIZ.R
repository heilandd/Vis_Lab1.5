


countfiles=c("Out_counts_Virus.R")
f_data=read.csv("samp_desc.csv", sep=";")
Data.character=list(ExpID="Gliosis_new_Virus", 
                    Researcher="Becker", 
                    Bioinformatic="Dieter Henri Heiland",
                    Institute="Medical Center Freiburg MILO Laboratory",
                    Date_of_Analysis="23.03.2020",
                    Datatype="RNA-seq",
                    Sequencer="Illumina",
                    Species="Human")



pipline_Create_Vizfile=function(Modus=c(fromMatrix, fromcOutcounts), 
                                CountMatrix=NA,
                                f_data, 
                                countfiles, 
                                Data.character, 
                                HOMER=F, 
                                Addgene=F, 
                                export="/Users/HenrikHeiland/Desktop/T-Cell Project/21_new/TC"){}
  
  message("Start Pipeline")
  ##----------------------------------------------------------------------------##
  ## Create the new class
  ##----------------------------------------------------------------------------##
  
  data_counts=setClass("data_counts", slots = c(counts="matrix", 
                                                norm_Exp = "matrix", 
                                                batch_corrected = "matrix", 
                                                used="matrix"))
  
  VIZ_MILO <- setClass("VIZ_MILO", slots = c(Data.character="list",
                                             fdata = "data.frame", 
                                             DE="list",
                                             condition_Analysis="character",
                                             data =   "data_counts" ,
                                             AutoEncoder="matrix",
                                             UMAP="matrix",
                                             cluster="data.frame",
                                             Marker_genes="data.frame",
                                             GSEA_sample_list="matrix",
                                             GSEA="list",
                                             Gene_Sets_used="data.frame"
  ))
  
  setMethod("initialize",signature = "VIZ_MILO", definition = function(.Object, count_matrix, f_data){
    .Object@fdata=f_data
    return(.Object)
  })
  
  ##----------------------------------------------------------------------------##
  ## Reqired Functions
  ##----------------------------------------------------------------------------##
  input_from_OutCounts=function(Out_counts,Samples_discription ){
    samples=nrow(Samples_discription)
    All_genes=unlist(lapply(1:samples,function(i){Out_counts[[i]]$HUGO}))
    All_genes=as.data.frame(as.character(All_genes[!duplicated(All_genes)]))
    names(All_genes)="genes"
    print("--------------- Start Merge Counts ------------------------")
    pb=txtProgressBar(min = 1, max = samples, initial = 1, char = "#",
                      width = 40, title=paste0("Progress Config Countfiles"))
    
    
    for(i in 1:samples){
      
      setTxtProgressBar(pb, i)
      l=Out_counts[[i]]
      l[,1]=as.character(l[,1])
      All_genes[,i+1]=0
      for(ix in 1:nrow(All_genes)){
        count=sum(l[l[,1]==as.character(All_genes[ix,1]),2])
        All_genes[ix,i+1]=count
        
      }
      
    }
    
    close(pb)
    
    input=All_genes
    return(input)
  }
  input_from_OutCounts_Virus=function(Out_counts,Samples_discription ){
    samples=nrow(Samples_discription)
    All_genes=unlist(lapply(1:samples,function(i){Out_counts[[i]]$Virus}))
    All_genes=as.data.frame(as.character(All_genes[!duplicated(All_genes)]))
    names(All_genes)="genes"
    print("--------------- Start Merge Counts ------------------------")
    pb=txtProgressBar(min = 1, max = samples, initial = 1, char = "#",
                      width = 40, title=paste0("Progress Config Countfiles"))
    
    
    for(i in 1:samples){
      
      setTxtProgressBar(pb, i)
      l=Out_counts[[i]]
      l[,1]=as.character(l[,1])
      All_genes[,i+1]=0
      for(ix in 1:nrow(All_genes)){
        count=sum(l[l[,1]==as.character(All_genes[ix,1]),2])
        All_genes[ix,i+1]=count
        
      }
      
    }
    
    close(pb)
    
    input=All_genes
    return(input)
  }
  DESEQ_DHH=function(dds, min_read){
    
    
    print("--------------- DESEQ_DHH  ------------------------")
    dds <- dds[ rowSums(counts(dds)) >= min_read, ]
    dim(dds)
    rld <- rlog(dds, blind=FALSE)
    if(length(unique(sample@fdata$Batch))>1){assay(rld) <- sva::ComBat(assay(rld), batch=sample@fdata$Batch)}
    sample@data@norm_Exp=as.matrix(assay(rld))
    dds=DESeq(dds)
    return(dds)
  }
  
  
  ##----------------------------------------------------------------------------##
  ## Start input basic informations
  ##----------------------------------------------------------------------------##
 
  
  sample=VIZ_MILO(f_data=f_data)
  sample@Data.character=Data.character
  rownames(sample@fdata)=sample@fdata$Sample 
  
  
  
  if(Modus=="fromcOutcounts"){
   
    ##----------------------------------------------------------------------------##
  ## Nanopore Seq
  ##----------------------------------------------------------------------------##
  ##----------------------------------------------------------------------------##
  ## Input Coount files
  ##----------------------------------------------------------------------------##
  
  
  
  if(length(countfiles)>1){
    
    Out_counts=do.call(c,lapply(1:length(countfiles), function(z) readRDS(countfiles[z]) ))
    
  }else{(Out_counts=readRDS(countfiles))}
  
  Samples_discription=sample@fdata
  counts=input_from_OutCounts(Out_counts,Samples_discription)
  counts=data.frame(counts[2:ncol(counts)], row.names = counts$genes)
  sample@data@counts=as.matrix((na.omit(counts)))
  colnames(sample@data@counts)=sample@fdata$Sample 
  
  }
  
  
  if(Modus=="fromMatrix"){
    
    counts=as.matrix(CountMatrix)
    
  }

  
  
  #For Viral or other species:
  if(otherS=T){
    Samples_discription=sample@fdata
    counts=input_from_OutCounts_Virus(Out_counts,Samples_discription)
    counts=data.frame(counts[2:ncol(counts)], row.names = counts$genes)
    sample@data@counts=as.matrix((na.omit(counts)))
    colnames(sample@data@counts)=sample@fdata$Sample
  }
   
  

##----------------------------------------------------------------------------##
## DE
##----------------------------------------------------------------------------##


counts=as.matrix(counts)
feat=sample@fdata

head(counts)

library(DESeq2)
feat$group=as.factor(sample@fdata$group)
feat$treatment=as.factor(sample@fdata$treatment)

min_read=1

dds_group=DESEQ_DHH(DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ group), min_read=min_read)
dds_treat=DESEQ_DHH(DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ treatment), min_read=min_read)

dds=DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ group)
dds <- dds[ rowSums(counts(dds)) >= min_read, ]
dim(dds)
rld <- rlog(dds, blind=FALSE)
if(length(unique(sample@fdata$Batch))>1){assay(rld) <- sva::ComBat(assay(rld), batch=sample@fdata$Batch)}
sample@data@norm_Exp=as.matrix(assay(rld))


sample@DE=list(dds_group, dds_treat)
sample@fdata=feat
names(sample@DE)=c("group", "treatment")
sample@condition_Analysis=c("group", "treatment")

diff_gene=results(dds_group)

test_DE= data.frame(results(dds_group))
dim(test_DE)

library(ggplot2)

temp=with(test_DE, data.frame(x=c(0,1,2,3,3.5,3.5,3,2,1,0), y=c(0,2,2,2,2,-2,-2,-2,-2,0)))
p=ggplot() + 
  xlab("Realtive Counts") + ylab("Fold Change")+
  geom_hline(yintercept=0, linetype="dashed")+
  scale_color_viridis(direction=1)+
  geom_polygon(data = temp, aes(x,y), fill="lightblue", alpha=0.2)+
  geom_point(data=test_DE, aes(x=test_DE$lfcSE, y=test_DE$log2FoldChange, color=-log(test_DE$pvalue), size=-log(test_DE$pvalue)))+ 
  theme_classic()+ 
  theme(
    plot.margin = margin(t = 50, r = 50, b = 50, l = 50, unit = "pt"),
    axis.text.y = element_text(color="black"),
    axis.text.x = element_text(color="black")
    )+
  ylim(-2,2)


p 






##----------------------------------------------------------------------------##
## Data ready for the GSEA
##----------------------------------------------------------------------------##

### Add new GS or load the old ones


#Add new

### Selected GS for Analysis
library(clusterProfiler)
library(gtools)
library(DESeq2)
library(clusterProfiler)


if(Addgene==T){
  newGS=readRDS("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/MILO_Geneset.RDS")
  
  nGS_TCells=read.csv("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/New_Genesets/TC_GS.csv", sep=";")
  nGS_TCells=nGS_TCells[,c("ont", "gene")]
  
  #Stimmulation Datasets
  HOMER_DE_to_gmt=function(folder, GS_name){
    message(paste0("Number of new GS lists were found in folder:   ", length(dir(folder))))
    
    GS_fromfolder=as.data.frame(do.call(rbind,lapply(1:length(dir(folder)), function(i){
      y=read.csv(dir(folder)[i])
      
      a=gsub("group", "",dir(folder)[i] )
      a=gsub(".txt", "",a)
      ont=paste0("MILO_",GS_name,"_",a)
      
      out=data.frame(ont=ont, gene=as.character(y$V1))
      return(out)
    })))
    
    return(GS_fromfolder)
  }
  
  nGS_TCells_Stim=HOMER_DE_to_gmt(folder="~/Desktop/RNA-Seq_Analysis/Nico/Merged/HOMER/Input",
                                  GS_name="TCELL_STIM")
  
  
  names(newGS)==names(nGS_TCells_Stim)
  
  MsigDB1=rbind(MsigDB1,newGS, nGS_TCells, nGS_TCells_Stim)
  
  saveRDS(MsigDB1, "MILO_MsigDB1_14_Feb.RDS")
  
  
}


#load old
MsigDB1=readRDS("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/MILO_MsigDB1_14_Feb.RDS")


sample@Gene_Sets_used=MsigDB1
#Get new genesets


#Input explanation:  res=data.frame, GMT -> GeneSets
GSEA_DHH=function(res, GMT){
  res=res[order(res$log2FoldChange, decreasing=T), ]
  ranks=data.frame(ID=as.character(rownames(res)),t=as.numeric(res$log2FoldChange))
  ranks <- setNames(ranks$t, ranks$ID)
  egmt1 <- GSEA(ranks, TERM2GENE=GMT, verbose = T, pvalueCutoff= 1)
}



#Matrix with all possible GSEA conditions
to_test=levels(sample@fdata[,sample@condition_Analysis[1]])
df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
cond_mat=matrix(NA,nrow(df_test), 2)
colnames(cond_mat)=sample@condition_Analysis
for(z in 1:nrow(df_test)){
  cond_mat[z,sample@condition_Analysis[1]]=paste0(df_test[z,1],"_",df_test[z,2])
  
}
to_test=levels(sample@fdata[,sample@condition_Analysis[2]])
df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
for(z in 1:nrow(df_test)){
  cond_mat[z,sample@condition_Analysis[2]]=paste0(df_test[z,1],"_",df_test[z,2])
  
}


#Start list with GSEA of all conditions
GSEA_out=lapply(1:length(sample@condition_Analysis), function(i){
    
  to_test=levels(sample@fdata[,sample@condition_Analysis[i]])
  df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)

  GSEA_out2=lapply(1:nrow(df_test), function(j){
    
    DE_in=sample@DE[[sample@condition_Analysis[i]]]
    res=data.frame(results(DE_in, contrast = c(sample@condition_Analysis[i],df_test[j,1],df_test[j,2])))
    return(GSEA_DHH(res, MsigDB1))
    
  })
  
})

#Add correct name to lists
names(GSEA_out)=sample@condition_Analysis
names(GSEA_out[[sample@condition_Analysis[1]]])=as.character(na.omit(cond_mat[,1]))
names(GSEA_out[[sample@condition_Analysis[2]]])=as.character(na.omit(cond_mat[,2]))

#Export into class
sample@GSEA=GSEA_out
sample@GSEA_sample_list=cond_mat


##----------------------------------------------------------------------------##
## HOMER
##----------------------------------------------------------------------------##

if(HOMER==T){
  message("HOMER Motif Enrnrichment Analysis")
  
  path=getwd()
  dir.create("HOMER")
  setwd(paste0(getwd(), "/HOMER"))
  dir.create("Input")
  dir.create("Output")
  message("HOMER Data will be saved in: ")
  message(getwd())
  
  #save genelist
  length_motiv=100
  setwd(paste0(getwd(), "/Input"))
  
  bash=c("#!/bin/bash")
  
  HOMER=lapply(1:length(sample@condition_Analysis), function(i){
    
    to_test=levels(sample@fdata[,sample@condition_Analysis[i]])
    df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
    
    HOMER2=lapply(1:nrow(df_test), function(j){
      
      setwd(paste0(path, "/HOMER/Input"))
      print(paste0(sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt"))
      
      DE_in=sample@DE[[sample@condition_Analysis[i]]]
      res=data.frame(results(DE_in, contrast = c(sample@condition_Analysis[i],df_test[j,1],df_test[j,2])))
      
      genes_UP=head(rownames(res[order(res$log2FoldChange, decreasing = F), ]),length_motiv)
      write.table(as.matrix(genes_UP), 
                  file=paste0(sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt"),
                  quote=FALSE, sep='\t', row.names = F)
      
      
      pathtopl="/Users/HenrikHeiland/homer/"
      
      command=paste0(paste0("findMotifs.pl"), " ",
                     paste0(path, "/HOMER/Input/", sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt")
                     ," human ", 
                     paste0(path, "/HOMER/Output/",sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv) ,
                     " -start -400 -end 100 -len 6,8,10,12 -p 8  ")
      
      bash<<-c(bash,command)
      
      
      
      
    })
    
    
  })
  
  write.table(data.frame(bash), "HOMER.sh", quote = F, row.names = F, col.names = F)
  
  
}





##----------------------------------------------------------------------------##
## Export Data
##----------------------------------------------------------------------------##


sample@data@norm_Exp
sample@fdata=feat
saveRDS(sample,paste0(export,"/",sample@Data.character[[1]],Sys.Date(), ".RDS"))





counts["NC_001664.2_Human_herpesvirus_6A,_complete_genome", ]



sample_data=readRDS("sample_data.RDS") 


sample_data@data@counts
rownames(sample_data@data@count)

sample_data@Gene_Sets_used



sample=sample_data




























#####Test#####
#GSEA_res=GSEA_out[[sample@condition_Analysis[2]]][[as.character(na.omit(cond_mat[,2]))[1]]]
#GSEA_res2=GSEA_out[[sample@condition_Analysis[2]]][[as.character(na.omit(cond_mat[,2]))[1]]]@result


#############################################################################################
############# ----------------- GSEA plot function----------------------#####################
#############################################################################################


gseaplot_DHH=function(object,geneSetID,main="",add_line=T, color="black", cex=2, Add=F){
  
  require(enrichplot)
  gseaScores <- getFromNamespace("gseaScores", "DOSE")
  gsInfo <- function(object, geneSetID) {
    geneList <- object@geneList
    
    if (is.numeric(geneSetID))
      geneSetID <- object@result[geneSetID, "ID"]
    
    geneSet <- object@geneSets[[geneSetID]]
    exponent <- object@params[["exponent"]]
    df <- gseaScores(geneList, geneSet, exponent, fortify=TRUE)
    df$ymin=0
    df$ymax=0
    pos <- df$position == 1
    h <- diff(range(df$runningScore))/20
    df$ymin[pos] <- -h
    df$ymax[pos] <- h
    df$geneList <- geneList
    
    df$Description <- object@result[geneSetID, "Description"]
    return(df)
  }
  gsdata <- gsInfo(object, geneSetID)
  
  if(Add==T){
    points(x=gsdata[gsdata$position==1, ]$x, y=gsdata[gsdata$position==1, ]$runningScore,pch=16, lwd=1, cex=cex,bty="n", 
           ylim=c(-1,1), main=main, xlab="", ylab="Enrichment Score",
           xaxt='n', col=color)
    if(add_line==T){points(x=gsdata$x, y=gsdata$runningScore, type = "l",lty=1, col=color)}
    
  }
  if(Add==F){
    par(mar=c(5,5,5,5), las=2)
    plot(x=gsdata[gsdata$position==1, ]$x, y=gsdata[gsdata$position==1, ]$runningScore,pch=16, lwd=1, cex=cex,bty="n", 
         ylim=c(-1,1), main=main, xlab="", ylab="Enrichment Score",
         xaxt='n',col=color, xlim=c(head(gsdata$x,1),tail(gsdata$x,1)))
    if(add_line==T){points(x=gsdata$x, y=gsdata$runningScore, type = "l",lty=1,col=color)}
    abline(h=0, lty=1, lwd=1)
  }
}

geneSetID="BIOCARTA_EGFR_SMRTE_PATHWAY"
geneSetID="REACTOME_RORA_ACTIVATES_GENE_EXPRESSION"

gseaplot_DHH(GSEA_res,geneSetID=geneSetID, main=geneSetID,Add=F ,color="green" )
gseaplot_DHH(GSEA_res,geneSetID=geneSetID, main=geneSetID,Add=T ,color="red" )













##----------------------------------------------------------------------------##
## Microarray from LY
##----------------------------------------------------------------------------##

library(pd.clariom.s.human)
library(limma)
library(oligo)
library(affycoretools)
library(clariomdhumanprobeset.db)
library(clariomdhumantranscriptcluster.db)
library(affy)



celFiles <- list.celfiles("~/Desktop/RNA-Seq_Analysis/LY/CEL_FILES", full.names=TRUE)
rawData <- read.celfiles(celFiles,verbose = TRUE)
transcript.eset=oligo::rma(rawData) 
transcript.eset <- annotateEset(transcript.eset, clariomdhumantranscriptcluster.db)


boxplot(transcript.eset)
hist(transcript.eset)

plotPCA(transcript.eset, addtext = sampleNames(transcript.eset))


transcript.eset@featureData


genome_data=na.omit(as.data.frame(transcript.eset@featureData@data))
write.exprs(transcript.eset,file="data2_norm.csv", sep=";")
exp=read.csv("data2_norm.csv", sep=";", header=T, row.names = 1)






exp=read.csv("data2_norm.csv", sep=",")
feat_ma=read.csv("Sample Description.csv", sep=",")

fdata$File=names(exp)
write.table(fdata, "Sample_Description.csv", sep=";")

fdata=read.csv("Sample_Description.csv", sep=";")
exp=exp[,fdata$File]
names(exp)=fdata$Sample
exp=exp[genome_data$PROBEID, ]
exp1=cbind(data.frame(Symbol=genome_data$SYMBOL), exp)

#Correct counts
summ_dup_genes=function(exp, Symbol=c("Symbol"), sample_Size){
  listofdup=exp[duplicated(exp[,Symbol]), Symbol]
  listofdup=listofdup[!duplicated(listofdup)]
  exp_n=as.data.frame(do.call(rbind, lapply(1:length(listofdup), function(i){
    print(i)
    genes=exp[exp[,Symbol]==listofdup[i], names(exp)!=Symbol]
    genes_2=as.data.frame(t(colMeans(genes)))
    rownames(genes_2)=listofdup[i]
    return(genes_2)
  })))
  exp_x=exp[!duplicated(exp[,Symbol]), ]
  rownames(exp_x)=exp_x[,Symbol]
  exp=rbind(exp_x[,names(exp)!=Symbol], exp_n)
  return(exp)
}
exp=summ_dup_genes(exp1, Symbol=c("Symbol"), sample_Size=c(ncol(exp1)-1))

exp1=exp



##----------------------------------------------------------------------------##
## Microarray
##----------------------------------------------------------------------------##

#Expression Matrix and feature input

exp1[1:10, 1:10]
#fdata=data.frame(Barcode=NA, File=NA, Sample=feat$Sample, group=paste0("Cond_",feat$Group), treatment=paste0("T_",feat$Treatment), Batch=feat$Batch, row.names = feat$ID)
#write.table(fdata, "finalSD_csv", sep=";")

#Check data 


min(expr)
counts=exp1
counts=na.omit(counts)

counts=(exp(counts))*1000

min(counts)
max(counts)
counts=counts[,fdata$Sample]

for(i in 1:ncol(counts)){counts[,i]=as.integer(counts[,i])}

sample@fdata=fdata











