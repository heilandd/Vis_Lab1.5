
##----------------------------------------------------------------------------##
## UI-Load Data
##----------------------------------------------------------------------------##

tab_load_data <- tabItem(
  tabName = "loadData",
  fluidRow(
    column(12,
           titlePanel("Load data"),
           fileInput(
             inputId = "input_file",
             label = "File",
             multiple = FALSE,
             accept = c("RDS"),
             width = '350px',
             buttonLabel = "Browse...",
             placeholder = "No file selected"
           )
    )
  ),
  fluidRow(
    valueBoxOutput("load_data_number_of_cells"),
    valueBoxOutput("load_data_number_of_Groups"),
    valueBoxOutput("load_data_number_of_Batches"),
    tags$p( "   The Experimental Set up was defined as follows", style = "font-size: 150%;"),
    tags$p( " ", style = "font-size: 150%;"),
    valueBoxOutput("ExpID"),
    valueBoxOutput("Researcher"),
    valueBoxOutput("Bioinformatic"),
    valueBoxOutput("Institute"),
    valueBoxOutput("Date_of_Analysis"),
    valueBoxOutput("Datatype"),
    valueBoxOutput("Sequencer"),
    valueBoxOutput("Species"),
    
    box(
      width = 12, status = "warning", solidHeader = TRUE,
      DT::DTOutput("Sample_datadescrip")
    ),
    
    
    box(
      title = "About VIS_Lab",
      helpText(" The Tool was written by Dr. D. H.. Heiland, Microenvironemnet and Immunology Laboratory any questions mailto: dieter.henrik.heiland@uniklinik-freiburg.de") 
    )
    
    
  )
)
