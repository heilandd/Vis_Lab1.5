##----------------------------------------------------------------------------##
## Server-Load Data
##----------------------------------------------------------------------------##
# number of samples
output$load_data_number_of_cells <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(nrow(sample_data()@fdata), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of samples",
    color = "light-blue"
  )
})

output$load_data_number_of_Groups <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(length(unique(sample_data()@fdata$group)), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of groups",
    color = "light-blue"
  )
})

output$load_data_number_of_Batches <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(length(unique(sample_data()@fdata$Batch)), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of batches",
    color = "light-blue"
  )
})

output$load_data_number_of_Batches <- renderValueBox({
  valueBox(
    value = if ( !is.null(sample_data()) ) formatC(length(unique(sample_data()@fdata$Batch)), format = "f", big.mark = ",", digits = 0) else 0,
    subtitle = "Number of batches",
    color = "light-blue"
  )
})


output$ExpID <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$ExpID else 0}, style = "font-size: 60%;"),
    subtitle = "Experimental ID",
    color = "light-blue"
  )
})


output$Researcher <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Researcher else 0}, style = "font-size: 60%;"),
    subtitle = "Researcher",
    color = "light-blue"
  )
})

output$Bioinformatic <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Bioinformatic else 0}, style = "font-size: 60%;"),
    subtitle = "Responsible for Bioinformatics",
    color = "light-blue"
  )
})

output$Institute <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Institute else 0}, style = "font-size: 60%;"),
    subtitle = "Institute",
    color = "light-blue"
  )
})

output$Date_of_Analysis <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Date_of_Analysis else 0}, style = "font-size: 60%;"),
    subtitle = "Date_of_Analysis",
    color = "light-blue"
  )
})


output$Datatype <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Datatype else 0}, style = "font-size: 60%;"),
    subtitle = "Datatype",
    color = "light-blue"
  )
})

output$Sequencer <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Sequencer else 0}, style = "font-size: 60%;"),
    subtitle = "Sequencer",
    color = "light-blue"
  )
})



output$Species <- renderValueBox({
  valueBox(
    value = tags$p( {if ( !is.null(sample_data()@Data.character) ) sample_data()@Data.character$Species else 0}, style = "font-size: 60%;"),
    subtitle = "Species",
    color = "light-blue"
  )
})



output$Sample_datadescrip <- DT::renderDT({
  sample_data()@fdata})
  




