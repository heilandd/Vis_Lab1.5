#!/bin/bash
 echo ###################### Launch VisLab ######################## 
cd /Users/HenrikHeiland/Desktop/VisLab/Vis_Lab1.5/VIS_Lab_v
Rscript Vis_Lab.R 
