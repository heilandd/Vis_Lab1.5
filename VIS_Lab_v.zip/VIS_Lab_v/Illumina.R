library(stringi)

##Fastq Innput
folder=getwd()
gtf=c("~/Desktop/Bonn_Hippo/anno.gtf")
Genome=c("~/Desktop/Bonn_Hippo/Genome") 


##start
options(stringsAsFactors = F)

samples=data.frame(Samples=dir(pattern = ".fastq.gz"), ID=NA, Read=NA)
for(i in 1:nrow(samples)){
  samples[i,]$ID=unlist(strsplit(as.character(samples[i,1]), "_"))[3] 
  if(samples[i,]$ID=="A" | samples[i,]$ID=="B") {
    samples[i,]$ID=unlist(strsplit(as.character(samples[i,1]), "_"))[4]}
  }


samples$Read=rep(c(1,2), n=nrow(samples)/2)


samplesrun=unique(samples$ID)


STAR_wrapper=function(samplesrun, human=T, Viral=T, Microbiom=T){
  #human alignment + umapped reads
  for(i in 1:length(samplesrun)){
    
    message(paste0("Start with analysis in: ", samplesrun[i]))
    reads=paste0(getwd(),"/", as.character(samples[samples$ID==samplesrun[i], 1]))
    
    if(human==T){
      system(paste0("mkdir ", paste0(samplesrun[i],"_unmapped")))
      
      input_R1=reads[1]
      input_R2=reads[2] 
      setwd(paste0(folder,"/",paste0(samplesrun[i],"_unmapped")))
      system(paste0("STAR --runThreadN 14 -- twopassMode Basic  --readFilesCommand gunzip -c --outSAMtype BAM SortedByCoordinate ", " ",
                    "--readFilesIn ", input_R1, "  ", input_R2, " ", 
                    "--genomeDir ",Genome," ",
                    "--sjdbGTFfile ",gtf, " --quantMode GeneCounts TranscriptomeSAM --outFilterScoreMinOverLread 0.33 ",
                    "--outFilterMatchNminOverLread 0.33 --outFilterType BySJout --outFilterMultimapNmax 20 --alignSJoverhangMin 8 ",
                    "--alignSJDBoverhangMin 1 --outFilterMismatchNmax 999 – sjdbOverhang 74 --alignIntronMin 20 --alignIntronMax 1000000 ",
                    "--alignMatesGapMax 1000000 --outSAMunmapped Within" 
      )
      )
    }
    if(viral==T){
      setwd(paste0(folder,"/",paste0(samplesrun[i],"_unmapped")))
       ## Isolate unmapped reads
      
      system("samtools view -hf 4 Aligned.sortedByCoord.out.bam > unmapped.bam")
      
      #BAM to fastq
      system("bedtools bamtofastq -i unmapped.bam -fq unmapped.fa ")
      
      #Usese Bowtie2 to align to viral genome
      ref_virus="/Users/HenrikHeiland/Desktop/Bonn_Hippo/virus_Ref/virus"
      system(paste0("bowtie2 -x ", ref_virus ," -U unmapped.fa  -S virus.sam"))
      
      #Sam to BAM
      system(paste0("samtools view -S -b  virus.sam  > virus.bam"))
      system(paste0("samtools sort  virus.bam >  sort_virus.bam"))
      system(paste0("samtools index  sort_virus.bam"))
      system(paste0("samtools idxstats sort_virus.bam > Viral_readcount.txt"))
      
    }
    if(Microbiom==T){
      setwd(paste0(folder,"/",paste0(samplesrun[i],"_unmapped")))
      ## Isolate unmapped reads
      
      #system("samtools view -hf 4 Aligned.sortedByCoord.out.bam > unmapped.bam")
      
      #BAM to fastq
      #system("bedtools bamtofastq -i unmapped.bam -fq unmapped.fa ")
      
      #Usese Bowtie2 to align to viral genome
      ref_Microbiom="/Users/HenrikHeiland/Desktop/Bonn_Hippo/virus_Ref/Microbiom"
      system(paste0("bowtie2 -x ", ref_Microbiom ," -U unmapped.fa  -S Microbiom.sam"))
      
      #Sam to BAM
      system(paste0("samtools view -S -b  Microbiom.sam  > Microbiom.bam"))
      system(paste0("samtools sort  Microbiom.bam >  sort_Microbiom.bam"))
      system(paste0("samtools index  sort_Microbiom.bam"))
      system(paste0("samtools idxstats sort_Microbiom.bam > Counts_Microbiom.txt"))
    }
    
    
    
    
    setwd(folder)
  }
}








Out_counts=lapply(1:length(samplesrun), function(i){
  
  setwd(paste0(
    folder, "/", samplesrun[i]
  )
  )
  
  message(paste0("Start with analysis in: ", samplesrun[i]))
  
  #Load data to back to R
  reads=read.table("ReadsPerGene.out.tab")
  names(reads)=c("ENST","Mapped", "R1", "R2")
  reads=reads[5:nrow(reads), ]
  reads$genes=apply(reads, 1, function(x){return(unlist(strsplit(as.character(x[1]), "[.]"))[1])})
  reads=reads[reads$Mapped>=1, ]
  
  
  library(annotables)
  libraryx=grch38_tx2gene
  library2=grch38
  reads$HUGO=apply(reads,1,function(x){
    yy=library2[library2$ensgene==x[5], ]$symbol 
    return(yy[1])
  })
  
  #Remove duplicates
  
  reads=reads[!is.na(reads$HUGO), ]
  genes=unlist(reads[!duplicated(reads$HUGO), ]$HUGO)
  
  reads_new=data.frame(do.call(rbind, lapply(1:length(genes), function(ix){
    sym=genes[ix]
    n_reads=sum(reads[reads$HUGO==sym, ]$Mapped)
    out=data.frame(sym,n_reads)
    names(out)=c("HUGO", "Counts")
    return(out)
  })))
  
  dim(reads_new)
  
  return(reads_new)
  
  
  
})
saveRDS(Out_counts, file = "Out_counts.R")
write.table(samples, file="samples.csv", sep=";")


Out_counts_Virus=lapply(1:length(samplesrun), function(i){
  
  setwd(paste0(
    folder, "/", paste0(samplesrun[i],"_unmapped")
  )
  )
  
  message(paste0("Start with analysis in: ", samplesrun[i]))
  
  #Load data to back to R
  reads=read.table("Viral_readcount.txt")
  names(reads)=c("Virus","Size", "Counts", "XX")
  reads_new=reads[,c(1,3)]
  
  return(reads_new)
  
  
  
})
names(Out_counts_Virus)=samplesrun
saveRDS(Out_counts_Virus, file = "Out_counts_Virus.R")



### bowetie 2 ref genome
# bowtie2-build *.fna outputfile

system("bowtie2-build all_seqs.fa Microbiom")




