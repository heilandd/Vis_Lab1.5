pipline_Create_Vizfile=function(Modus=c("fromMatrix", "fromcOutcounts")[2], 
                                CountMatrix=NA,
                                f_data, 
                                countfiles, 
                                Data.character, 
                                HOMER=F, 
                                Addgene=F, 
                                minCounts=5,
                                norm=c("rlog", "vst")[1],
                                Outputname=Data.character[[1]],
                                export="/Users/HenrikHeiland/Desktop/T-Cell Project/21_new/TC"){
  
  message("Start Pipeline")
  ##----------------------------------------------------------------------------##
  ## Create the new class
  ##----------------------------------------------------------------------------##
  
  data_counts=setClass("data_counts", slots = c(counts="matrix", 
                                                norm_Exp = "matrix", 
                                                batch_corrected = "matrix", 
                                                used="matrix"))
  
  VIZ_MILO <- setClass("VIZ_MILO", slots = c(Data.character="list",
                                             fdata = "data.frame", 
                                             DE="list",
                                             condition_Analysis="character",
                                             data =   "data_counts" ,
                                             AutoEncoder="matrix",
                                             UMAP="matrix",
                                             cluster="data.frame",
                                             Marker_genes="data.frame",
                                             GSEA_sample_list="matrix",
                                             GSEA="list",
                                             Gene_Sets_used="data.frame"
  ))
  
  setMethod("initialize",signature = "VIZ_MILO", definition = function(.Object, count_matrix, f_data){
    .Object@fdata=f_data
    return(.Object)
  })
  
  ##----------------------------------------------------------------------------##
  ## Reqired Functions
  ##----------------------------------------------------------------------------##
  input_from_OutCounts=function(Out_counts,Samples_discription ){
    samples=nrow(Samples_discription)
    All_genes=unlist(lapply(1:samples,function(i){Out_counts[[i]]$HUGO}))
    All_genes=as.data.frame(as.character(All_genes[!duplicated(All_genes)]))
    names(All_genes)="genes"
    print("--------------- Start Merge Counts ------------------------")
    pb=txtProgressBar(min = 1, max = samples, initial = 1, char = "#",
                      width = 40, title=paste0("Progress Config Countfiles"))
    
    
    for(i in 1:samples){
      
      setTxtProgressBar(pb, i)
      l=Out_counts[[i]]
      l[,1]=as.character(l[,1])
      All_genes[,i+1]=0
      for(ix in 1:nrow(All_genes)){
        count=sum(l[l[,1]==as.character(All_genes[ix,1]),2])
        All_genes[ix,i+1]=count
        
      }
      
    }
    
    close(pb)
    
    input=All_genes
    return(input)
  }
  
  DESEQ_DHH=function(dds){
    
    
    print("--------------- DESEQ_DHH  ------------------------")
    dds <- dds[ rowSums(counts(dds)) >= minCounts, ]
    dim(dds)
    if(norm=="rlog"){
      rld <- rlog(dds, blind=FALSE)
    }else{rld <- varianceStabilizingTransformation(dds)}
    
    if(length(unique(sample@fdata$Batch))>1){assay(rld) <- sva::ComBat(assay(rld), batch=sample@fdata$Batch)}
    sample@data@norm_Exp=as.matrix(assay(rld))
    dds=DESeq(dds)
    return(dds)
  }
  
  
  ##----------------------------------------------------------------------------##
  ## Start input basic informations
  ##----------------------------------------------------------------------------##
  
  
  sample=VIZ_MILO(f_data=f_data)
  rownames(sample@fdata)=sample@fdata$Sample 
  sample@Data.character=Data.character
  
  
  if(Modus=="fromcOutcounts"){
    
    ##----------------------------------------------------------------------------##
    ## Nanopore Seq
    ##----------------------------------------------------------------------------##
    ##----------------------------------------------------------------------------##
    ## Input Coount files
    ##----------------------------------------------------------------------------##
    
    
    
    if(length(countfiles)>1){
      
      Out_counts=do.call(c,lapply(1:length(countfiles), function(z) readRDS(countfiles[z]) ))
      
    }else(Out_counts=readRDS(countfiles))
    
    Samples_discription=sample@fdata
    counts=input_from_OutCounts(Out_counts,Samples_discription)
    counts=data.frame(counts[2:ncol(counts)], row.names = counts$genes)
    sample@data@counts=as.matrix((na.omit(counts)))
    colnames(sample@data@counts)=sample@fdata$Sample 
    
  }
  
  if(Modus=="fromMatrix"){
    
    sample@data@counts=as.matrix((na.omit(CountMatrix)))
    colnames(sample@data@counts)=sample@fdata$Sample 
    
    counts=as.matrix(CountMatrix)
    
  }
  
  ##----------------------------------------------------------------------------##
  ## DE
  ##----------------------------------------------------------------------------##
  
  
  counts=as.matrix(counts)
  feat=sample@fdata
  
  
  library(DESeq2)
  feat$group=as.factor(sample@fdata$group)
  feat$treatment=as.factor(sample@fdata$treatment)
  
  
  
  dds_group=DESEQ_DHH(DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ group))
  dds_treat=DESEQ_DHH(DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ treatment))
  
  dds=DESeqDataSetFromMatrix(countData = sample@data@counts ,DataFrame(sample@fdata), ~ group)
  dds <- dds[ rowSums(counts(dds)) >= minCounts, ]
  dim(dds)
  if(norm=="rlog"){
    rld <- rlog(dds, blind=FALSE)
  }else{rld <- varianceStabilizingTransformation(dds)}
  
  if(length(unique(sample@fdata$Batch))>1){assay(rld) <- sva::ComBat(assay(rld), batch=sample@fdata$Batch)}
  sample@data@norm_Exp=as.matrix(assay(rld))
  
  
  sample@DE=list(dds_group, dds_treat)
  sample@fdata=feat
  names(sample@DE)=c("group", "treatment")
  sample@condition_Analysis=c("group", "treatment")
  
  diff_gene=results(dds_group)
  
  
  ##----------------------------------------------------------------------------##
  ## Data ready for the GSEA
  ##----------------------------------------------------------------------------##
  
  ### Add new GS or load the old ones
  
  
  #Add new
  
  ### Selected GS for Analysis
  library(clusterProfiler)
  library(gtools)
  library(DESeq2)
  library(clusterProfiler)
  
  
  if(Addgene==T){
    newGS=readRDS("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/MILO_Geneset.RDS")
    
    nGS_TCells=read.csv("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/New_Genesets/TC_GS.csv", sep=";")
    nGS_TCells=nGS_TCells[,c("ont", "gene")]
    
    #Stimmulation Datasets
    HOMER_DE_to_gmt=function(folder, GS_name){
      message(paste0("Number of new GS lists were found in folder:   ", length(dir(folder))))
      
      GS_fromfolder=as.data.frame(do.call(rbind,lapply(1:length(dir(folder)), function(i){
        y=read.csv(dir(folder)[i])
        
        a=gsub("group", "",dir(folder)[i] )
        a=gsub(".txt", "",a)
        ont=paste0("MILO_",GS_name,"_",a)
        
        out=data.frame(ont=ont, gene=as.character(y$V1))
        return(out)
      })))
      
      return(GS_fromfolder)
    }
    
    nGS_TCells_Stim=HOMER_DE_to_gmt(folder="~/Desktop/RNA-Seq_Analysis/Nico/Merged/HOMER/Input",
                                    GS_name="TCELL_STIM")
    
    
    names(newGS)==names(nGS_TCells_Stim)
    
    MsigDB1=rbind(MsigDB1,newGS, nGS_TCells, nGS_TCells_Stim)
    
    saveRDS(MsigDB1, "MILO_MsigDB1_14_Feb.RDS")
    
    
  }
  
  
  #load old
  MsigDB1=readRDS("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab_v1.4.1/MILO_MsigDB1_14_Feb.RDS")
  
  
  sample@Gene_Sets_used=MsigDB1
  #Get new genesets
  
  
  #Input explanation:  res=data.frame, GMT -> GeneSets
  GSEA_DHH=function(res, GMT){
    res=res[order(res$log2FoldChange, decreasing=T), ]
    ranks=data.frame(ID=as.character(rownames(res)),t=as.numeric(res$log2FoldChange))
    ranks <- setNames(ranks$t, ranks$ID)
    egmt1 <- GSEA(ranks, TERM2GENE=GMT, verbose = T, pvalueCutoff= 1)
  }
  
  
  
  #Matrix with all possible GSEA conditions
  to_test=levels(sample@fdata[,sample@condition_Analysis[1]])
  df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
  cond_mat=matrix(NA,nrow(df_test), 2)
  colnames(cond_mat)=sample@condition_Analysis
  for(z in 1:nrow(df_test)){
    cond_mat[z,sample@condition_Analysis[1]]=paste0(df_test[z,1],"_",df_test[z,2])
    
  }
  to_test=levels(sample@fdata[,sample@condition_Analysis[2]])
  df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
  for(z in 1:nrow(df_test)){
    cond_mat[z,sample@condition_Analysis[2]]=paste0(df_test[z,1],"_",df_test[z,2])
    
  }
  
  
  #Start list with GSEA of all conditions
  GSEA_out=lapply(1:length(sample@condition_Analysis), function(i){
    
    to_test=levels(sample@fdata[,sample@condition_Analysis[i]])
    df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
    
    GSEA_out2=lapply(1:nrow(df_test), function(j){
      
      DE_in=sample@DE[[sample@condition_Analysis[i]]]
      res=data.frame(results(DE_in, contrast = c(sample@condition_Analysis[i],df_test[j,1],df_test[j,2])))
      return(GSEA_DHH(res, MsigDB1))
      
    })
    
  })
  
  #Add correct name to lists
  names(GSEA_out)=sample@condition_Analysis
  names(GSEA_out[[sample@condition_Analysis[1]]])=as.character(na.omit(cond_mat[,1]))
  names(GSEA_out[[sample@condition_Analysis[2]]])=as.character(na.omit(cond_mat[,2]))
  
  #Export into class
  sample@GSEA=GSEA_out
  sample@GSEA_sample_list=cond_mat
  
  
  ##----------------------------------------------------------------------------##
  ## HOMER
  ##----------------------------------------------------------------------------##
  
  if(HOMER==T){
    message("HOMER Motif Enrnrichment Analysis")
    
    path=getwd()
    dir.create("HOMER")
    setwd(paste0(getwd(), "/HOMER"))
    dir.create("Input")
    dir.create("Output")
    message("HOMER Data will be saved in: ")
    message(getwd())
    
    #save genelist
    length_motiv=100
    setwd(paste0(getwd(), "/Input"))
    
    bash=c("#!/bin/bash")
    
    HOMER=lapply(1:length(sample@condition_Analysis), function(i){
      
      to_test=levels(sample@fdata[,sample@condition_Analysis[i]])
      df_test=permutations(n=length(to_test), r=2, v=to_test, repeats.allowed=F)
      
      HOMER2=lapply(1:nrow(df_test), function(j){
        
        setwd(paste0(path, "/HOMER/Input"))
        print(paste0(sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt"))
        
        DE_in=sample@DE[[sample@condition_Analysis[i]]]
        res=data.frame(results(DE_in, contrast = c(sample@condition_Analysis[i],df_test[j,1],df_test[j,2])))
        
        genes_UP=head(rownames(res[order(res$log2FoldChange, decreasing = F), ]),length_motiv)
        write.table(as.matrix(genes_UP), 
                    file=paste0(sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt"),
                    quote=FALSE, sep='\t', row.names = F)
        
        
        pathtopl="/Users/HenrikHeiland/homer/"
        
        command=paste0(paste0("findMotifs.pl"), " ",
                       paste0(path, "/HOMER/Input/", sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv,".txt")
                       ," human ", 
                       paste0(path, "/HOMER/Output/",sample@condition_Analysis[i],df_test[j,1],"_UP_",df_test[j,2],length_motiv) ,
                       " -start -400 -end 100 -len 6,8,10,12 -p 8  ")
        
        bash<<-c(bash,command)
        
        
        
        
      })
      
      
    })
    
    write.table(data.frame(bash), "HOMER.sh", quote = F, row.names = F, col.names = F)
    
    
  }
  
  
  
  
  
  ##----------------------------------------------------------------------------##
  ## Export Data
  ##----------------------------------------------------------------------------##
  
  
  sample@data@norm_Exp
  sample@fdata=feat
  
  print(paste0(export,"/",Outputname,Sys.Date(), ".RDS"))

  
  saveRDS(sample,paste0(export,"/",Outputname,Sys.Date(), ".RDS"))
  
}