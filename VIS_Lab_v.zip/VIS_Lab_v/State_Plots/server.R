##----------------------------------------------------------------------------##
## Server-State_plots
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## uiOutput
##----------------------------------------------------------------------------##

output$GS1=renderUI({
  selectInput(inputId="GS1", 
              label="Select Pathway 1:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[1]
  )
})

output$GS2=renderUI({
  selectInput(inputId="GS2", 
              label="Select Pathway 2:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[2]
  )
})

output$GS3=renderUI({
  selectInput(inputId="GS3", 
              label="Select Pathway 3:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[3]
  )
})

output$GS4=renderUI({
  selectInput(inputId="GS4", 
              label="Select Pathway 4:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[4]
  )
})

output$GS_select_vio=renderUI({
  selectInput(inputId="GS_select_vio", 
              label="Select Pathway:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[1]
  )
})
output$col_enrichmnet=renderUI({
  selectInput(inputId="col_enrichmnet", 
              label="Select Pathway to Color:",
              choices = c(NA,as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(NA)
  )
})


output$Select_Gene=renderUI({
  selectInput(inputId="Select_Gene", 
              label="Select Gene",
              choices = c(NA,rownames(sample_data()@data@norm_Exp)),
              selected= rownames(sample_data()@data@norm_Exp)[1],
              multiple = TRUE
  )
})
output$select_pal=renderUI({
  selectInput(inputId="select_pal", 
              label="Color Set",
              choices = c("RdYlBu", "viridis", "inferno"),
              selected= "viridis",
              multiple = F
  )
})
output$select_Treatmant_col=renderUI({
  selectInput(inputId="select_Treatmant_col", 
              label="Color Set",
              choices = c(NA,sample_data()@condition_Analysis),
              selected= c(NA,sample_data()@condition_Analysis)[1],
              multiple = F
  )
})

output$xscale=renderUI({
  sliderInput("xscale", "Scale Axis:", 0, 20, 1, step=0.01)
})
output$Text_Plot=renderUI({
  sliderInput("Text_Plot", "Scale Lables:", 0, 1, 0.5, step=0.01)
})
output$Text_Plot2=renderUI({
  sliderInput("Text_Plot2", "Scale Lables:", 0, 3, 0.8, step=0.01)
})


output$select_vio=renderUI({
  selectInput(inputId="select_vio", 
              label="Select Pathway Vioplot:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[4]
  )
})
output$VIO_Select=renderUI({
  selectInput(inputId="VIO_Select", 
              label="Select Condition:",
              choices = c(as.character((sample_data()@condition_Analysis))),
              selected= c(as.character((sample_data()@condition_Analysis)))[1]
  )
})
output$h=renderUI({
  sliderInput("h", "H-Factor", 0, 10, 3, step=0.01)
})


output$T3D=renderUI({
  selectInput(inputId="T3D", 
              label="Select Pathway:",
              choices = c(as.character(unique(sample_data()@Gene_Sets_used$ont))),
              selected= c(as.character(unique(sample_data()@Gene_Sets_used$ont)))[1:6],
              multiple = T
  )
})



##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
require(GSVA)
source(paste0(folder,"/Functions/Metaplot_4D_DASH.R"),local = T)
source(paste0(folder,"/Functions/Trajectory_State.R"),local = T)
source(paste0(folder,"/Functions/Trajectory_State_3D.R"),local = T)
source(paste0(folder,"/Functions/Vioplot_DHH.R"),local = T)








##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##

inp=reactive({
  genes_selected=sample_data()@Gene_Sets_used$gene[sample_data()@Gene_Sets_used$ont==input$select_vio]
  print(genes_selected)
  mod=levels(sample_data()@fdata[,input$VIO_Select])
  inp=matrix(NA, 1000, length(mod))
  for(i in 1: length(mod) ){
    samples_select=sample_data()@fdata[as.character(sample_data()@fdata[,input$VIO_Select])==mod[i], ]$Sample
    x=sample_data()@data@norm_Exp[rownames(sample_data()@data@norm_Exp) %in% genes_selected, samples_select ]
    x=as.numeric(rowSums(x))
    inp[,i]=c(x, rep(NA, nrow(inp)-length(x)))
  }
  colnames(inp)=mod
  
  print(inp)
  return(inp)
})

output$Scatter <- renderPlot({

  if(input$select_pal=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10)}
  if(input$select_pal=="viridis"){pal=viridis(50)}else{pal=inferno(50)}
  print(c(input$GS1,input$GS2,input$GS3,input$GS4))
  
  Metaplot_4D_DASH(sample=sample_data(),
                   Geneset=c(input$GS1,input$GS2,input$GS3,input$GS4),
                   genes=input$Select_Gene,
                   col_samples=input$select_Treatmant_col,
                   pal=pal,
                   xscale=input$xscale,
                   signature=input$col_enrichmnet,
                   cex_GS=input$Text_Plot)

 
})
output$Trajectory <- renderPlot({
  
  if(input$select_pal=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10)}
  if(input$select_pal=="viridis"){pal=viridis(50)}else{pal=inferno(50)}
  
  Trajectory_State(sample=sample_data(),
                   Geneset=c(input$GS1,input$GS2,input$GS3,input$GS4 ),
                   genes=input$Select_Gene,
                   col_samples=input$select_Treatmant_col,
                   pal=pal,
                   xscale=input$xscale,
                   signature=input$col_enrichmnet,
                   cex_GS=input$Text_Plot2)
  
  
})
output$Trajectory_3D <- renderPlotly({
  
Trajectory_State_3D(sample=sample_data(),
                  Geneset_m=c(input$T3D),
                   genes="NA",
                   col_samples=input$select_Treatmant_col,
                   xscale=1,
                   signature="NA",
                   cex_GS=1)})


output$Vioplot <- renderPlot({
 
  
  Vioplot_DHH(inp(), h=input$h, ylab="Normalized Expression of Geneset")
  
  
})




# Downloads of Plots  
output$downloadplot_Scatter <- downloadHandler(
  filename = function() { paste("Scatter", input$GS1,"_",input$GS2,"_",input$GS3,"_",input$GS4, '.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    if(input$select_pal=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10)}
    if(input$select_pal=="viridis"){pal=viridis(50)}else{pal=inferno(50)}
    
    Metaplot_4D_DASH(sample=sample_data(),
                     Geneset=c(input$GS1,input$GS2,input$GS3,input$GS4 ),
                     genes=input$Select_Gene,
                     col_samples=input$select_Treatmant_col,
                     pal=pal,
                     xscale=input$xscale,
                     signature=input$col_enrichmnet,
                     cex_GS=input$Text_Plot)
    
    
    dev.off()},
  contentType = "application/pdf"
)

output$downloadplot_Trajectory<- downloadHandler(
  filename = function() { paste("Scatter", input$GS1,"_",input$GS2,"_",input$GS3,"_",input$GS4, '.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    
    if(input$select_pal=="RdYlBu"){pal=colorRampPalette(rev(brewer.pal(9, "RdYlBu")), bias=1)(10)}
    if(input$select_pal=="viridis"){pal=viridis(50)}else{pal=inferno(50)}
    
    Trajectory_State(sample=sample_data(),
                     Geneset=c(input$GS1,input$GS2,input$GS3,input$GS4 ),
                     genes=input$Select_Gene,
                     col_samples=input$select_Treatmant_col,
                     pal=pal,
                     xscale=input$xscale,
                     signature=input$col_enrichmnet,
                     cex_GS=input$Text_Plot2)
    
    
    dev.off()},
  contentType = "application/pdf"
)

output$download_Vioplot <- downloadHandler(
  filename = function() { paste(input$select_vio, '.pdf', sep='') },
  content = function(file) {
    pdf(file, useDingbats = F)
    Vioplot_DHH(inp(), h=input$h, ylab="Normalized Expression of Geneset")
    dev.off()},
  contentType = "application/pdf"
)


