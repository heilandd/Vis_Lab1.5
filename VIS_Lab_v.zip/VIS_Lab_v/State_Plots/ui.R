
##----------------------------------------------------------------------------##
## UI-State_Plots
##----------------------------------------------------------------------------##

tab_State_Plots <- tabItem(
  tabName = "StatePlots",

  fluidRow(

    #Selection Box
    box(
      width = 4, status = "warning", solidHeader = TRUE,
      title = "Select conditions for Scatter Plot:",
      
      #### Checkbox for Groups
      uiOutput("GS1"),
      uiOutput("GS2"),
      uiOutput("GS3"),
      uiOutput("GS4"),
      uiOutput("col_enrichmnet"),
      uiOutput("Select_Gene"),
      uiOutput("select_Treatmant_col"),
      uiOutput("select_pal"),
      uiOutput("xscale"),
      
    ),
    
    
    #Plot TabBox
    tabBox(
      title = "", 
      id="Plots_Scatter",
      height = 700,width = 8,
      
      tabPanel(title="State Scatter",
               downloadLink("downloadplot_Scatter", "PDF"),
               uiOutput("Text_Plot"),
               plotOutput("Scatter")),
      
      tabPanel(title="Trajectory Scatter",
               downloadLink("downloadplot_Trajectory", "PDF"),
               uiOutput("Text_Plot2"),
               plotOutput("Trajectory")),
      
      tabPanel(title="Vioplot States: ",
               downloadLink("download_Vioplot", "PDF"),
               uiOutput("select_vio"),
               uiOutput("VIO_Select"),
               uiOutput("h"),
               plotOutput("Vioplot"))
      
    ),
    box(
      title = "3D Trajectory Plot", 
      id="3D_Scatter",
      height = 900,width = 10,status = "warning",
      "Plrase Select 6 Pathways (A Trajectory is defined by two pathways i.e. first trajectory PW1 vs. PW2)",
      "",
      "No plot is rendert as long as no conditions is selected",
      
      uiOutput("T3D"),
      plotlyOutput("Trajectory_3D")
    )
    


    
    ),
  )


