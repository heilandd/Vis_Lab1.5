Vis_Labe <- function(
  maxFileSize = 800
){
  
  ################## Sources of shiny parts of the App
  
  source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab/Start_page/info.R")
  
  ##--------------------------------------------------------------------------##
  ## Load server and UI functions.
  ##--------------------------------------------------------------------------##
  source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab/App/ALL_UI.R")
  source("~/Desktop/Projekt_Metabolom/Bioinformatic Tests/VIS_Lab/App/ALL_server.R")
  
  ##--------------------------------------------------------------------------##
  ## Launch app.
  ##--------------------------------------------------------------------------##
  shinyApp(ui = ui, server = server)
  
}

library(shinydashboard)
library(shiny)




shinyApp(ui = ui, server = server)


















