
##----------------------------------------------------------------------------##
## UI-DE
##----------------------------------------------------------------------------##

tab_DEAnalysis <- tabItem(
  tabName = "DEAnalysis",
  fluidRow(valueBoxOutput("DE"),
           valueBoxOutput("FDR"),
           valueBoxOutput("TotalGenes")),
  fluidRow(
    
    
    
    
    #Selection Box
    box(
      width = 3, status = "warning", solidHeader = TRUE,
      title = "Select conditions for Differential expressed Genes:",
      
    #### Checkbox for Groups
    uiOutput("Choice"),
    
    "Please select two conditions to Analyze:",
    
    uiOutput("C1"),
    
    uiOutput("C2"),
                
    #### Select Gene
    
    uiOutput("Gene"),
    
    
    ),
    
    
    #Plot TabBox
    tabBox(
      title = "", 
      id="Plots2",
      width = 8,
      
      tabPanel(title="Volcano Plot",
              downloadLink("downloadVolcano_plot", "PDF"),
              dropdownButton(
              inputId = "MyDropDownB1",
              tags$h3("Options Volcano Plot"),
                       
              uiOutput("FC"),
              uiOutput("xlim_vplot"),
              uiOutput("P_value"),
              
              circle = F, 
              status = "info", 
              icon = icon("gear"), 
              width = "300px",
              tooltip = tooltipOptions(title = "Change Options Plot !")
              
              
              ),
              withSpinner((plotOutput("Volcano_plot", inline=F)))),
      
      tabPanel(title="Autopipe",
               downloadLink("downloadplot_Autopipe", "PDF"),
               uiOutput("threshold"),
               uiOutput("Number_of_genes_X"),
               uiOutput("GSEA_A"),
               uiOutput("show_sil"),
               uiOutput("plot_mean_sil"),
               
               
               
               withSpinner((plotOutput("Autopipe", inline=F)))),
      
      tabPanel(title="Heatmap",
               downloadLink("downloadHeatmap", "PDF"),
               uiOutput("Number_of_genes"),
               withSpinner(plotOutput("Heatmap")))
      
    ),
    
    tabBox(
      title = "Plots", 
      id="Plots1",
      width = 6,
      tabPanel(title="Violine Plot",
               downloadLink("downloadplot_violin", "PDF"),
               uiOutput("Get_Info"),
               uiOutput(("h1")),
               plotOutput("plot_violin")),
               
      tabPanel(title="Barplot",
               uiOutput("xlim_barplot"),
               downloadLink("downloadplot_bar", "PDF"),
               plotOutput("Barplot")),
      
      tabPanel(title="Pubmed",
               "For more information of gene and additional query :",
               uiOutput("Query1"),
               uiOutput("Query2"),
               uiOutput("Query3"),
               uiOutput("Pubmed")
               )
               
      
    ),
    
    #Put Table Here
    box(
      width = 12, status = "warning", solidHeader = TRUE,
      title = "Overview of the used Sample Description:",
      DT::DTOutput("DE_Tab")),
      
    
    
    ),
  )

