##----------------------------------------------------------------------------##
## Server-DE
##----------------------------------------------------------------------------##


##----------------------------------------------------------------------------##
## UiOutputs
##----------------------------------------------------------------------------##
output$Choice <- renderUI({
selectInput(inputId="Choice", 
            label="Select Condition Factor:",
            choices = c(sample_data()@condition_Analysis),
            selected= c(sample_data()@condition_Analysis)[1]
)
})

output$C1 <- renderUI({
  selectInput(inputId="C1", 
              label="Condition Factor 1:",
              choices = c(levels(sample_data()@fdata[, input$Choice])),
              selected= c(levels(sample_data()@fdata[, input$Choice]))[1]
  )
})


output$C2 <- renderUI({
  selectInput(inputId="C2", 
              label="Condition Factor 2:",
              choices = c(levels(sample_data()@fdata[, input$Choice])),
              selected= c(levels(sample_data()@fdata[, input$Choice]))[2]
  )
})


output$P_value <- renderUI({
  selectInput(inputId="P_value", 
              label="Select P-value for ploting:",
              choices = c("padj", "pvalue"),
              selected= c("padj", "pvalue")[1]
  )
})


output$Gene <- renderUI({
  selectInput(inputId="Gene", 
              label="Select Gene:",
              choices = c(rownames(sample_data()@data@norm_Exp)),
              selected= NULL
  )
})

output$Number_of_genes <- renderUI({
  selectInput(inputId="Number_of_genes", 
              label="Number of genes for Heatmap:",
              choices = c(10,20,30,40,50,60,70,80,90,100),
              selected= 20
  )
})

output$Number_of_genes_X <- renderUI({
  selectInput(inputId="Number_of_genes_X", 
              label="Number of genes for Autopipe:",
              choices = c(10,20,30,40,50,60,70,80,90,100),
              selected= 20
  )
})



output$h1=renderUI({
  sliderInput("h1", "H-Factor", 0, 10, 3, step=0.01)
})

output$FC=renderUI({
  sliderInput("FC", "H-Factor", 0, 10, 1, step=0.01)
})



output$threshold=renderUI({
  sliderInput("threshold", "H-threshold", 0, 10, 1, step=0.01)
})

output$xlim_vplot=renderUI({
  sliderInput("xlim_vplot", "X-lim", -100, 100, value = c(-40,40), step=0.01)
})

output$xlim_barplot=renderUI({
  sliderInput("xlim_barplot", "y-lim", -5, 20, value = c(0,5), step=0.01)
})


output$GSEA_A=renderUI({
  checkboxInput("GSEA_A", "Add  GSEA", FALSE)
})

output$show_sil=renderUI({
  checkboxInput("show_sil", "Show SIL", FALSE)
})

output$plot_mean_sil=renderUI({
  checkboxInput("plot_mean_sil", "Show Cluster Determination", FALSE)
})




output$Get_Info=renderUI({
  actionButton(inputId='Get_Info', label="Get Gene Informaton", 
               icon = icon("th"), 
               onclick =paste0("window.open('https://www.genecards.org/cgi-bin/carddisp.pl?gene=",input$Gene, "','_blank')")
  )
})


output$Query1=renderUI({
  textInput("Query1", "First Item:", "")
})


output$Query2=renderUI({
  textInput("Query2", "2nd Item: ", "")
})

output$Query3=renderUI({
  textInput("Query3", "3rd Item:", "")
})


output$Pubmed=renderUI({
  actionButton(inputId='Pubmed', label="Check Pubmed for Informations:", 
               icon = icon("th"), 
               onclick =paste0("window.open('https://www.ncbi.nlm.nih.gov/pubmed/?term=",input$Gene,"+",input$Query1,"+",input$Query2,"+",input$Query3,"','_blank')")
  )
})



##----------------------------------------------------------------------------##
## Functions for Tab
##----------------------------------------------------------------------------##
require(dplyr)
require(DESeq2)
source(paste0(folder,"/Functions/Vioplot_DHH.R"),local = T)



diff_gene <- reactive({
  
  #call DE from input
  select=input$Choice
  print(select)
  diff_gene=results(sample_data()@DE[[select]], contrast = c(select, input$C1, input$C2))
  #print(diff_gene)
  return(diff_gene)
  
})


plot_DE=function(diff_gene, xlim_vplot){
  

  FC=input$FC
  p=input$P_value
  
  if(is.null(FC)){FC=1.5}
  if(is.null(p)){p="padj"}
  
  p_dd=max(-log10(diff_gene[,p]), na.rm = T)
  
  
  lim=list(x=c(min(diff_gene$log2FoldChange), max(diff_gene$log2FoldChange)), y=c(0, max(-log10(diff_gene[,p]),na.rm = T)))
  
  plot(x=diff_gene$log2FoldChange, y=c(-log10(diff_gene[,p])), pch=16,cex=0.5, 
       bty="n", xlab="Differential Expression Genes (Log2 Fold Change)", ylab="", 
       ylim=c(0,lim$y[2]+lim$y[2]/10), xlim=c(xlim_vplot),
       axes=F)
  
  ##Arrows
  
  arrows(c(lim$x[1]-lim$x[1]/6), -lim$y[2]/80, c(lim$x[2]-lim$x[2]/6), -lim$y[2]/80,length = 0.1,code=3, lwd=4)
  polygon(x=c(0,0), y=c(-lim$y[2]/10, 0), lwd=4)
  
  
  #Quaters for Significans
  xx=c(lim$x[1]+(lim$x[1]/50),-FC,-FC,lim$x[1]+(lim$x[1]/50))
  xx2=c(lim$x[2]+(lim$x[2]/50),FC,FC,lim$x[2]+(lim$x[2]/50))
  
  yy=c(-log10(0.05),-log10(0.05), lim$y[2]+(lim$y[2]/10), lim$y[2]+(lim$y[2]/10))
  
  polygon(x=xx,y=yy,lty=2);polygon(x=xx2,y=yy,lty=2)
  
  
  #abline(v=FC, lty=2);abline(v=-FC, lty=2);abline(h=-log10(0.05), lty=2)
  
  if(length(unique(is.na(diff_gene$padj)))>1 ){diff_gene[is.na(diff_gene$padj), ]$padj=1} 
  
  points(x=diff_gene[diff_gene$log2FoldChange>FC & diff_gene[,p]<0.05 | diff_gene$log2FoldChange<c(-FC) & diff_gene[,p]<0.05 , ]$log2FoldChange, 
         y=c(-log10(diff_gene[diff_gene$log2FoldChange>FC & diff_gene[,p]<0.05 | diff_gene$log2FoldChange<c(-FC) & diff_gene[,p]<0.05 , p])), 
         pch=16, col="red", cex=0.5)
  
  
  ####Add Genes
  nr=20
  xpos_left=lim$x[1]+(lim$x[1]/5)
  xpos_right=lim$x[2]+(lim$x[2]/5)
  position=seq(lim$y[2],lim$y[1], length.out = nr )
  
 #negative Genes to print
  neg=diff_gene[order(diff_gene$log2FoldChange, decreasing = F), ]
  neg=neg[neg$log2FoldChange<c(-FC), ]
  neg=neg[order(neg[,p], decreasing = F), ]
  
  pos=diff_gene[order(diff_gene$log2FoldChange, decreasing = T), ]
  pos=pos[pos$log2FoldChange>c(FC), ]
  pos=pos[order(pos[,p], decreasing = F), ]
  
  
  
  for(i in 1:length(position)){
    
    #Text Gene
    text(x=xpos_left, y=position[i], labels = rownames(neg)[i], adj=1)
    polygon(x=c(xpos_left, neg$log2FoldChange[i] ), y=c(position[i], -log10(neg[i,p])))
    
  }
  for(i in 1:length(position)){
    
    #Text Gene
    text(x=xpos_right, y=position[i], labels = rownames(pos)[i], adj=0)
    polygon(x=c(xpos_right, pos$log2FoldChange[i] ), y=c(position[i], -log10(pos[i,p])))
    
  }
  
  
  
  
}



get_matrix=function(x, Choice){
  counts=sample_data()@data@norm_Exp
  feat=sample_data()@fdata
  
  #counts=sample_data@data@counts
  #feat=sample_data@fdata
  
  print(counts[1:4,1:4])
  print(dim(counts))
  
  
  
  #Selected condtions from the Check
  G1=levels(feat[,Choice])
  
  print(c(G1))
  
  ##Select Samples to test
  feat=feat[feat[,Choice] %in% c(G1), ]
  counts=counts[,rownames(feat)]
  
  print(feat)
  print(dim(counts))
  
  gene=input$Gene
  print(gene)
  
  
  mat=matrix(NA, nrow(feat),  length(unique(feat[,Choice])))
  print(mat)
  
  lv=unique(feat[,Choice])
  
  for(i in 1:ncol(mat)){
    mat[,i]=c(as.numeric(counts[gene, as.character(feat[feat[,Choice]==lv[i], ]$Sample)]), rep(NA,nrow(mat)-length(as.numeric(counts[gene, as.character(feat[feat[,Choice]==lv[i], ]$Sample)]))))  
  }
  
  colnames(mat)=paste0("Group_", lv)
  
  print(mat)
  return(mat)
}

Barplot_SC=function(input,min_x=0,Text_cex=1, points=T, 
                    main="main",
                    ylab="",
                    ylim=c(0,c(max(input,na.rm = TRUE)+3)),
                    mar=c(6,4,4,4), 
                    col_Schema=F,
                    col_Self=c("red", "grey"),
                    p_values=T,
                    AbstandxAxe=0.2,
                    AbstandBalken=0.1,
                    AbstandPWert=0.1){
  
  
  
  
  if(class(input)=="matrix"){len=ncol(input)}else{print("Input needs to be matrix")}
  par(mar=mar,xaxs = "i",yaxs = "i")
  maxx=0
  for(i in 1:ncol(input)){maxx=c(maxx,max(na.omit(input[,i])))}
  
  plot(x=c(1,len+1), y=c(c(min_x-c(max(maxx)/29)),max(maxx)), bty="n", type="n",ylab=ylab, xlab="",xaxt="n", main=main,ylim=ylim)
  
  if (col_Schema==T){
    require(RColorBrewer); rf <- colorRampPalette(rev(brewer.pal(9,'Set1')))
    r <- rf(len)
    col=sample(r) 
  } else {col=col_Self}
  
  #plot
  for(i in 1: len){
    val=na.omit(input[,i])
    xx=c(i,i,i+0.8,i+0.8 )
    yy=c(min_x,mean(val), mean(val), min_x)
    polygon(x=xx,y=yy, col=col[i], border="black", cex=1)
  }
  for(i in 1: len){
    val=na.omit(input[,i])
    xx=c(i+0.4,i+0.4 )
    yy=c(mean(val), mean(val)+sd(val))
    polygon(x=xx,y=yy, col="black",cex=1)
    
    xx=c(i+0.3,i+0.5 )
    yy=c(mean(val)+sd(val), mean(val)+sd(val))
    polygon(x=xx,y=yy, col="black")
    
    
  }
  if(points==T){
    for(i in 1: len){
      val=na.omit(input[,i])
      points(x=rnorm(mean=i+0.4, sd=0.05, n=length(val)), y=as.numeric(val))
    }
  }
  
  if (p_values==T){
    if(ncol(input)>2){
      for(i in 1:c(ncol(input)-1)){
        p=t.test(as.numeric(na.omit(input[,i])),as.numeric(na.omit(input[,i+1])))$p.value
        text(x=c(i+0.8) ,y=c(max(input,na.rm = TRUE)+i/AbstandPWert), labels = paste("p=",round(p, digits = 3),cex=Text_cex, sep=""))
        polygon(x=c(i+0.4, i+1.4),y=c(max(input,na.rm = TRUE)+(i/AbstandBalken),max(input,na.rm = TRUE)+(i/AbstandBalken) ), col="black")
      }
      
    }
    else{
      p=t.test(as.numeric(na.omit(input[,1])),as.numeric(na.omit(input[,2])))$p.value
      text(x=1.8 ,y=c(max(input,na.rm = TRUE)+AbstandPWert), labels = paste("p=",round(p, digits = 3),cex=Text_cex, sep=""))
      polygon(x=c(1.4, 2.4),y=c(max(input,na.rm = TRUE)+AbstandBalken,max(input,na.rm = TRUE)+AbstandBalken ), col="black")
    }
  }
  
  
  #put Axisi
  polygon(x=c(0,len),y=c(0,0), col="black",cex=1)
  for(i in 1:len){
    polygon(y=c(c(-max(maxx)/35),max(maxx)/35),x=c(i+0.4,i+0.4), col="black",cex=1)
  }
  
  #input names
  
  text(seq(1,len,by=1)+0.4, par("usr")[3]-AbstandxAxe, srt = 60, adj= 1, xpd = TRUE,labels = colnames(input), cex=Text_cex)
}

heatmapDHH_DE_tab=function(x,DE){
  
  #Define input
  select=input$Choice
  print(select)
  #Select samples that were used in Analnalysis
  dd=c(input$C1, input$C2)
  #dd=c("Group_1", "Group_2")
  samples_in_use=c(as.character(x@fdata$Sample)[x@fdata[,select] %in% dd[1]],as.character(x@fdata$Sample)[x@fdata[,select] %in% dd[2]])
  
  
  print(samples_in_use)
  
  #Expressionfile
  exp=x@data@norm_Exp[,samples_in_use]
  
  #DE_Genes
  DE=data.frame(DE)
  DE$Genes=rownames(DE)
  
  #Number of genes that were printed in heatmap
  nr=as.numeric(input$Number_of_genes)
  
  
  
  #select Genes by mosly diff expressed genes
  DE=DE[DE$pvalue<0.05, ]
  print(head(DE))
  selected_Genes=c(head(DE[order(DE$log2FoldChange, decreasing = T), ]$Genes, nr/2),
                   head(DE[order(DE$log2FoldChange, decreasing = F), ]$Genes, nr/2) )
  print(selected_Genes)
  require(pheatmap);require(viridis)
  print(nr)
  
  pheatmap(exp[rev(selected_Genes),samples_in_use ],
           cluster_row = T,
           cluster_cols = F,
           scale="row",
           color = viridis(50),
           cutree_rows = 2,
           cutree_cols = 2)
}


#Autopipe Function
library(AutoPipe)
source(paste0(folder,"/Functions/Autopipe.R"),local = T)

##----------------------------------------------------------------------------##
##  Tab Outputs
##----------------------------------------------------------------------------##






output$Volcano_plot <- renderPlot({

  #diff_gene=as.data.frame(diff_gene())
  #print(head(diff_gene))
  #Print volcano plot
  if(is.null(input$xlim_vplot)){xlim_vplot=c(-40,40)}else{xlim_vplot=input$xlim_vplot}

  
  plot_DE(diff_gene(),xlim_vplot=xlim_vplot )

 
})
output$plot_violin <- renderPlot({
  ### Get Groups that need to be tested
  par(mar=c(5,5,5,5), las=1)
  Vioplot_DHH(get_matrix(sample_data(), Choice=input$Choice), h=input$h1, ylab="Normalized Expression of Geneset")
  
})



output$Barplot <- renderPlot({
  ### Get Groups that need to be tested
  mat=get_matrix(sample_data(), Choice=input$Choice)
  mat=mat/mat[1,1]
  par(mar=c(5,5,5,5), las=1)
  Barplot_SC(mat, col_Schema = T, main=input$Gene, ylab="Normalized Geneexpression", ylim=c(input$xlim_barplot))
  
  
})
output$DE_Tab <- DT::renderDT({
  out=data.frame(diff_gene())
  out=data.frame(Genes=rownames(out),FC= out$log2FoldChange, Adj_p_value=out$padj)
  
  },
  options = list(
    autoWidth = T,scrollX=T,
    columnDefs = list(list(width = '100px', targets = "_all"))
  ),rownames=F
  )


output$Heatmap <- renderPlot({
  heatmapDHH_DE_tab(x=sample_data(), DE=diff_gene())
})

output$Autopipe <- renderPlot({
  
  Choice=input$Choice
  
  message(Choice)
  
  library(AutoPipe)
  library(org.Hs.eg.db)
  
  data_out=sample_data()@data@norm_Exp
  
  new = clusterProfiler::bitr(rownames(data_out), fromType = "SYMBOL", 
                              toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
  new = new[!duplicated(new$ENTREZID), ]
  rownames(new) = new$ENTREZID
  data_out = data_out[new$SYMBOL, ]
  rownames(data_out) = new$ENTREZID
  
  
  me_x=data_out
  res<-AutoPipe::TopPAM(me_x,max_clusters = 10, TOP=1000)
  me_TOP=res[[1]]
  number_of_k=res[[3]]
  File_genes=Groups_Sup(me_TOP, me=me_x, number_of_k,TRw=-1)
  groups_men=File_genes[[2]]
  
  print(groups_men)
  
  feat=sample_data()@fdata
  
  #print(feat)
  #print( feat[rownames(groups_men), Choice] )
  
  groups_men$cluster=as.numeric(feat[rownames(groups_men),Choice])
  groups_men=groups_men[order(groups_men$cluster), ]
  
  
  print(groups_men)
  
  me_x=File_genes[[1]]
  me_x=na.omit(me_x)
  
  nr_gegenes=as.numeric(input$Number_of_genes_X)
  threshold=input$threshold
  
  message(paste0("threshold:", threshold, "Nr_Genes", nr_gegenes))
  
  print(dim(me_x))
  print(table(is.na(me_x)))
  
  
  Supervised_Cluster_Heatmap(groups_men = groups_men, gene_matrix=me_x,TOP_Cluster=nr_gegenes,
                                  genes_to_print=nr_gegenes,
                                  method="PAMR",show_sil=input$show_sil,print_genes=T,threshold=threshold,
                                 TOP = 1000,GSE=input$GSEA_A,plot_mean_sil=input$plot_mean_sil,stats_clust=res[[2]], db="h")
  
  
  
  
  
  
})






#Render Outputs on Top
output$DE <- renderValueBox({
  valueBox(
    value = nrow(data.frame(diff_gene()) %>% filter(pvalue<0.05)),
    subtitle = "Number of Significant DE",
    color = "light-blue"
  )})
output$FDR <- renderValueBox({
  valueBox(
    value = nrow(data.frame(diff_gene()) %>% filter(padj<0.05)),
    subtitle = "FDR corrected",
    color = "light-blue"
  )})
output$TotalGenes <- renderValueBox({
  valueBox(
    value = nrow(data.frame(diff_gene())),
    subtitle = "Number of Genes",
    color = "light-blue"
  )})


# Downloads of Plots  
output$downloadplot_violin <- downloadHandler(
  filename = function() { paste( 'Vioplot.pdf', sep='') },
  content = function(file) {pdf(file, useDingbats = F)
    ### Get Groups that need to be tested
    par(mar=c(5,5,5,5), las=1)
    Vioplot_DHH(get_matrix(sample_data(), Choice=input$Choice), h=input$h1, ylab="Normalized Expression of Geneset")
    
    dev.off()},
  contentType = "application/pdf"
)


output$downloadplot_Autopipe <- downloadHandler(
  filename = function() { paste("Autopipe.pdf", sep='') },
  content = function(file) {
    
    #dev.off()
    
    
    Choice=input$Choice
    
    message(Choice)
    
    library(AutoPipe)
    library(org.Hs.eg.db)
    
    data_out=sample_data()@data@norm_Exp
    
    new = clusterProfiler::bitr(rownames(data_out), fromType = "SYMBOL", 
                                toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
    new = new[!duplicated(new$ENTREZID), ]
    rownames(new) = new$ENTREZID
    data_out = data_out[new$SYMBOL, ]
    rownames(data_out) = new$ENTREZID
    
    
    me_x=data_out
    res<-AutoPipe::TopPAM(me_x,max_clusters = 10, TOP=1000)
    me_TOP=res[[1]]
    number_of_k=res[[3]]
    File_genes=Groups_Sup(me_TOP, me=me_x, number_of_k,TRw=-1)
    groups_men=File_genes[[2]]
    
    print(groups_men)
    
    feat=sample_data()@fdata
    groups_men$cluster=as.numeric(feat[rownames(groups_men),Choice])
    groups_men=groups_men[order(groups_men$cluster), ]
    me_x=File_genes[[1]]
    me_x=na.omit(me_x)
    nr_gegenes=as.numeric(input$Number_of_genes_X)
    threshold=input$threshold
    message(paste0("threshold:", threshold, "Nr_Genes", nr_gegenes))

   
    pdf(file, useDingbats = F)
    Supervised_Cluster_Heatmap(groups_men = groups_men, gene_matrix=me_x,TOP_Cluster=nr_gegenes,
                               genes_to_print=nr_gegenes,
                               method="PAMR",show_sil=input$show_sil,print_genes=T,threshold=threshold,
                               TOP = 1000,GSE=input$GSEA_A,plot_mean_sil=input$plot_mean_sil,stats_clust=res[[2]], db="h")
    
    
    
    
    dev.off()
    },
  contentType = "application/pdf"
)




output$downloadVolcano_plot <- downloadHandler(
  filename = function() { paste("Volcano_plot.pdf", sep='') },
  content = function(file) {
    pdf(file, useDingbats = F)
    plot_DE(diff_gene(), input$xlim_vplot)
    dev.off()},
  contentType = "application/pdf"
)

output$downloadHeatmap <- downloadHandler(
  filename = function() { paste("heatmapDHH_DE_tab.pdf", sep='') },
  content = function(file) {
    pdf(file, useDingbats = F)
    heatmapDHH_DE_tab(x=sample_data(), DE=diff_gene())
    dev.off()},
  contentType = "application/pdf"
)


output$downloadplot_bar <- downloadHandler(
  filename = function() { paste(input$Gene, '.pdf', sep='') },
  content = function(file) {
    pdf(file, useDingbats = F)
    mat=get_matrix(sample_data(), Choice=input$Choice)
    mat=mat/mat[1,1]
    par(mar=c(5,5,5,5), las=1)
    Barplot_SC(mat, col_Schema = T, main=input$Gene, ylab="Normalized Geneexpression", ylim=c(input$xlim_barplot))
    dev.off()},
  contentType = "application/pdf"
)




